

import javax.xml.soap.Node;
import java.io.*;

import java.net.*;
import java.security.MessageDigest;
import java.util.*;

public class Final {

    static Map<Long, String> hashinterval = new Hashtable<Long, String>();
    static Map<Long, Long> hashssr = new Hashtable<Long, Long>();
    static Map<Long, String> hashssriport = new Hashtable<Long, String>();
    static int PortNumber, inNetwork, length, m = 32, PeerNum = 0, successorport;
    static String sysaddr, ser, syskey, successorip;
    static String[] myfiles = new String[5];
    static String[] queryfiles;
    static String[] myhashfiles = new String[5];
    static FileWriter fw;
    static long mynodenum, successor, pred;
    static long[] fingers, extnodekeys;
    static ServerSocket NodeserverSocket;
    static Socket NodeclientSocket;
    static ArrayList<Long> keytablekey = new ArrayList<Long>();
    static Map<Long, String> keytableip = new Hashtable<Long, String>();
    static Map<Long, Integer> keytableport = new Hashtable<Long, Integer>();
    static Map<Long, ArrayList<String>> keytablefile = new Hashtable<Long, ArrayList<String>>();


    public static void main(String[] args) throws Exception {
        getmyfiles();
        getqueryfiles();
        for (int i = 0; i < 5; i++) {
            myhashfiles[i] = Myhash(myfiles[i]);
        }
        //sender("localhost", 9999,"this is to test if the sender is working");
        //String a = "0543 GIVEKY 16 10.0.0.7 1234 1099553005 Heat 10.0.0.7 1234 2041498291 Goodfellas 10.0.0.7 1234 4041416350 Ikiru 10.0.0.7 1234 3403611531 Some 10.0.0.7 1234 1895038148 Like 10.0.0.7 1234 3342483113 It 10.0.0.7 1234 2205905904 Hot 10.0.0.7 1234 3945533110 Some_Like 10.0.0.7 1234 3554791189 Like_It 10.0.0.7 1234 3632572256 It_Hot 10.0.0.7 1234 2878361557 Some_Like_It 10.0.0.7 1234 3730729157 Like_It_Hot 10.0.0.7 1234 2217666016 Some_Like_It_Hot 10.0.0.7 1234 1551826505 Groundhog 10.0.0.7 1234 2626964036 Day 10.0.0.7 1234 1270248494 Groundhog_Day";
        REG();

        startServer();
        startSender();
    }

    //CLIENT END OF THE PROGRAM
    public static void startSender() throws Exception {
        (new Thread() {
            @Override
            public void run() {
                try {
                    Scanner infromuser = new Scanner(System.in);

                    while (true) {
                        System.out.println("\nEnter command:\nDETAILS\nFINGERTABLE\nKEYTABLE\nSEARCH\nFILES\nEXIT\n\n");
                        String StringFromUser = infromuser.nextLine();

                        if (StringFromUser.equals("EXIT")) {
                            System.out.println("\nEXITING\n");
                            System.out.println("\nSENDING KEYS FROM KEY TABLE TO SUCCESSOR\n");
                            givekey();
                            System.out.println("\nSENDING UPIFN TO NODES\n");
                            System.out.println("\nSENDING UNREG TO BS\n");
                            UNREG();
                        } else if (StringFromUser.equals("FINGERTABLE")) {
                            for (int p = 1; p < m; p++) {
                                System.out.println(p + " - finger:" + fingers[p] + " - interval :" + hashinterval.get(fingers[p]) + " - Successor" + hashssr.get(fingers[p]));
                            }
                            System.out.println(hashssriport);
                        } else if (StringFromUser.equals("SEARCH")) {
                            System.out.println("\nSending SER command to nodes in routing table\n");
                            search();
                        } else if (StringFromUser.equals("FILES")) {
                            System.out.println("Files in this system are:");
                            for (int l = 0; l < 5; l++) {
                                System.out.println(myfiles[l]);
                            }
                        } else if (StringFromUser.equals("KEYTABLE")) {
                            for (int p = 0; p < keytablekey.size(); p++) {
                                System.out.println("key : " + keytablekey.get(p) + " - port : " + keytableport.get(keytablekey.get(p)) + " - IP : " + keytableip.get(keytablekey.get(p)) + " - file : " + keytablefile.get(keytablekey.get(p)));
                            }
                        } else if (StringFromUser.equals("DETAILS")) {
                            System.out.println("IPADDRESS:" + sysaddr + "\nPORT NUMBER:" + PortNumber);
                        } else {
                            String error = "0009 ERROR";
                            System.out.println(error);

                            //send error
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }


    //SERVER END OF THE PROGRAM
    public static void startServer() throws Exception {
        (new Thread() {
            @Override
            public void run() {
                try {
                    String clientSentence;
                    while (true) {
                        NodeclientSocket = NodeserverSocket.accept();
                        BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                        clientSentence = inFromClient.readLine();
                        System.out.println("Message received : " + clientSentence);
                        String[] splitcmd = clientSentence.split(" ");
                        String command = splitcmd[1];

                        if (command.equals("UPFIN")) {
                            if (splitcmd[2].equals("0")) {
                                UPFIN0(clientSentence);
                            } else {
                                UPFIN1(clientSentence);
                            }
                        } else if (command.equals("GETKY")) {
                            getkeyreceived(clientSentence);
                        } else if (command.equals("ADD")) {
                            addreceived(clientSentence);
                        } else if (command.equals("GIVEKY")) {
                            givekeyreceived(clientSentence);
                        } else if (command.equals("SER")) {
                            searchcheck(clientSentence);
                        } else if (command.equals("SEROK")) {
                            searchcheck(clientSentence);
                            if (splitcmd[2].equals("0")) {
                                System.out.println("Search result: file not found");
                            } else {
                                for (int i = 3; i < splitcmd.length + 3; i++) {
                                    System.out.println("*********************");
                                    System.out.println("IPADDRESS :" + splitcmd[i]);
                                    i++;
                                    System.out.println("PORT : " + splitcmd[i]);
                                    i++;
                                    System.out.println("FILENAME :" + splitcmd[i]);
                                    i++;
                                }
                            }
                        }


                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }


    //************************************************************
    //FUNCTION TO CREATE THE IDENTIFIER OF ANY STRING
    public static String Myhash(String yourString) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(yourString.getBytes());
        StringBuffer sb = new StringBuffer();
        byte[] thedigest = md.digest();
        for (byte b : thedigest) {
            sb.append(String.format("%02x", b & 0xff));
        }
        String s = (sb.substring(24)).toString();
        return (s);
    }


    //************************************************************
    //FUNCTION TO CALCULATE THE FINGERS OF A GIVEN NODE
    public static void fingerCal() throws Exception {

        int ringnum = (int) Math.pow(2, m);
        double i = 1;
        int l = 1;
        fingers = new long[(m + 1)];
        fingers[1] = (int) (((int) (Math.pow(2.0, (i - 1))) + mynodenum) % ringnum);

        i++;
        l++;
        while (((((int) (Math.pow(2.0, (i - 1))) + mynodenum) % ringnum) % ringnum) != (int) (fingers[1] - 1)) {
            fingers[l] = (int) (((int) (Math.pow(2.0, (i - 1))) + mynodenum) % ringnum);

            i++;
            l++;
        }
        long temp;
        for (int k = 1; k < 31; k++) {
            if (fingers[k] > fingers[k + 1]) {
                temp = fingers[k];
                fingers[k] = fingers[k + 1];
                fingers[k + 1] = temp;
                k = 0;
            }
        }
        createHashInterval();
    }


    //**********CREATES HASH INTERVAL TABLE*****************
    public static void createHashInterval() {
        System.out.println("creating interval column in finger table");
        for (int p = 1; p < m; p++) {
            String interval;
            if (p != m - 1) {
                interval = "" + fingers[p] + "," + fingers[p + 1];
            } else {
                interval = "" + fingers[p] + "," + (fingers[1] - 1);
            }
            hashinterval.put(fingers[p], interval);
        }


    }

    //*******CREATES THE HASH SUCCESSOR TABLE***********
    public static void hashsuccessor(String sen) {
        //extnodekeys = new long[]{1734613597L, 660855400L}; //SEND THE KEYS FROM REGOK HERE.
        //length REGOK no_peers IP_1 port_1 key_1 IP_2 port_2 key_2
        System.out.println("creating successor column in finger table");
        int j = 3;
        String[] splitcmd = sen.split(" ");
        int peerNum = Integer.parseInt(splitcmd[2]);
        if (peerNum == 0) {
            for (int p = 1; p <= m; p++) {
                hashssr.put(fingers[p], mynodenum);
            }
        } else if (peerNum > 0 && peerNum < 9000) {
            long[] keyarray = new long[peerNum];
            String[] portarray = new String[peerNum];
            String[] iparray = new String[peerNum];

            //LOOP TO SAVE ALL THE IPADDRESS, PORT AND KEYS IN DIFFERENT ARRAYS
            for (int i = 0; i < peerNum; i++) {
                iparray[i] = splitcmd[j];
                j++;
                portarray[i] = splitcmd[j];
                j++;
                keyarray[i] = Long.parseLong(splitcmd[j], 16);
                j++;

                //System.out.println("Node :"+i);
                //System.out.println(iparray[i]);
                //System.out.println(portarray[i]);
                //System.out.println(keyarray[i]+"\n");
            }
            int g = 1;
            //LOOP TO CHECK IF SUCCESSOR IS EQUAL TO FINGER.
            for (int p = 1; p <= m; p++) {
                for (j = 0; j < keyarray.length; j++) {
                    if (fingers[p] == keyarray[j]) {
                        g = 0;
                    }
                }
                if (g == 0) {
                    hashssr.put(fingers[p], fingers[p]);

                    g = 1;
                } else {
                    hashssr.put(fingers[p], mynodenum);
                }
            }

            //ASSIGNING SUCCESSOR IF SUCCESSOR IS NOT EQUAL TO FINGER
            for (int p = 1; p <= m; p++) {
                long succ = hashssr.get(fingers[p]);
                for (j = 0; j < keyarray.length; j++) {
                    long ltemp = 0L;
                    if (keyarray[j] == 0 || (keyarray[j] < fingers[p])) {
                        ltemp = keyarray[j];
                        keyarray[j] += (long) Math.pow(2, m);
                    }
                    succ = hashssr.get(fingers[p]);
                    if (succ < fingers[p]) {
                        succ += (long) Math.pow(2, m);
                    }
                    if (keyarray[j] > fingers[p] && keyarray[j] < succ) {
                        if (keyarray[j] == (long) Math.pow(2, m) || keyarray[j] == (long) Math.pow(2, m) + ltemp) {
                            keyarray[j] = ltemp;
                        }
                        hashssr.put(fingers[p], keyarray[j]);

                        //System.out.println(hashssr);
                    }
                    if (keyarray[j] == (long) Math.pow(2, m) || keyarray[j] == (long) Math.pow(2, m) + ltemp) {
                        keyarray[j] = ltemp;
                    }
                }
                if (p < m && succ != fingers[p] && hashssr.get(fingers[p + 1]) == fingers[p + 1] && hashssr.get(fingers[p + 1]) < succ) {
                    hashssr.put(fingers[p], hashssr.get(fingers[p + 1]));
                    //System.out.println(hashssr);
                }
            }

            for (int p = 1; p <= m; p++) {
                for (j = 0; j < keyarray.length; j++) {
                    if (hashssr.get(fingers[p]) == keyarray[j]) {
                        hashssriport.put(keyarray[j], iparray[j] + "_" + portarray[j]);
                    }
                }
            }
        }
    }

    //************TO SEND REG TO BS**************************
    public static void REG() throws Exception {
        System.out.println("enter port number");
        Scanner scanner = new Scanner(System.in);
        PortNumber = scanner.nextInt();

        //NodeclientSocket = new Socket("localhost", PortNumber);
        System.out.println("enter BSIP");
        String bsIp = scanner.next();
        System.out.println("enter BSport");
        int port = scanner.nextInt();
        //byte[] sendData = new byte[1024];
        //byte[] receiveData = new byte[1024];
        Enumeration e = NetworkInterface.getNetworkInterfaces();
        InetAddress ip = null;
        while (e.hasMoreElements()) {
            NetworkInterface n = (NetworkInterface) e.nextElement();

            Enumeration ee = n.getInetAddresses();
            while (ee.hasMoreElements()) {
                InetAddress in = (InetAddress) ee.nextElement();

                if (!in.isLoopbackAddress()) {

                    if (in.isSiteLocalAddress()) {

                        // Found non-loopback site-local address. Return it immediately...
                        ip = in;
                    }
                }
            }
        }
        InetAddress HostName1 = InetAddress.getLocalHost();
        sysaddr = ""+ip;

        //InetAddress HostName1 = InetAddress.getLocalHost();
        //sysaddr = "" + HostName1.getHostAddress();
        syskey = Myhash(sysaddr);
        NodeserverSocket = new ServerSocket(PortNumber,0,ip);
        mynodenum = Long.parseLong(syskey, 16);
        fingerCal();
        System.out.println(mynodenum);
        String sentence = "REG " + sysaddr + " " + PortNumber + " " + syskey;
        length = sentence.length() + 5;
        sentence = "00" + length + " " + sentence + " \n";
        length = 0;
        System.out.println("sentence is :" + sentence);
        InetAddress IPAddress = InetAddress.getByName(bsIp);
        ser = "" + bsIp;
        System.out.println(bsIp + "dest-ip");
        //sender(ser,7002,sentence);
        NodeclientSocket = new Socket(bsIp,port);
        PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
        PS.println(sentence);

        NodeclientSocket = NodeserverSocket.accept();
        BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
        String clientSentence = inFromClient.readLine();
        System.out.println("Message received : " + clientSentence);
        String[] splitcmd = clientSentence.split(" ");
        String command = splitcmd[1];
        REGOK(clientSentence);
    }

    //****TO SEND UNREG COMMAND TO BS********************
    public static void UNREG() throws Exception {
        String sentence = "UNREG " + syskey;
        length = sentence.length() + 5;
        sentence = "00" + length + " " + sentence + " \n";
        length = 0;
        System.out.println("sentence is :" + sentence);
        NodeclientSocket = new Socket(ser, PortNumber);
        PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
        PS.println(sentence);
        BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
        String clientSentence = inFromClient.readLine();
        System.out.println("Message received : " + clientSentence);
        String[] splitcmd = clientSentence.split(" ");
        splitcmd[2] = splitcmd[2].trim();
        if (splitcmd[2].equals("0")) {
            System.out.println("Unregistered from the BootstrapServer");
        } else if (splitcmd[2].equals("9999")) {
            System.out.println("Error while unregistering from the BootstrapServer");
        }
    }

    //**********WHEN REGOK IS RECEIVED FROM BS************
    public static void REGOK(String sen) throws Exception {
        //length REGOK no_peers IP_1 port_1 key_1 IP_2 port_2 key_2
        //String sen = "0036 REGOK 2 123.32.23.3 4455 e763da4c 123.0.0.1 1234 e987da5c";
        String[] splitcmd = sen.split(" ");
        PeerNum = Integer.parseInt(splitcmd[3]);
        if (PeerNum == 9999) {
            System.out.println("Error in command");
        }
        //else if(PeerNum == 0){System.out.println("No nodes in network");successor = mynodenum; successorip = sysaddr; successorport = PortNumber; pred = mynodenum; }
        else if (PeerNum == 9998) {
            System.out.println("Error: Node already registerd. Register first.");
            System.exit(0);
        } else if (PeerNum == 9997) {
            System.out.println("Error: BS full, cannot register");
            System.exit(0);
        } else {
            String[] keyarray = new String[PeerNum];
            String[] portarray = new String[PeerNum];
            String[] iparray = new String[PeerNum];

            int j = 3;
            //LOOP TO SAVE ALL THE IPADDRESS, PORT AND KEYS IN DIFFERENT ARRAYS
            for (int i = 0; i < PeerNum; i++) {
                iparray[i] = splitcmd[j];
                j++;
                portarray[i] = splitcmd[j];
                j++;
                keyarray[i] = splitcmd[j];
                j++;

                System.out.println("Node :" + i);
                System.out.println(iparray[i]);
                System.out.println(portarray[i]);
                System.out.println(keyarray[i] + "\n");
            }
            long[] longkeyarray = new long[keyarray.length];

            //CONVERTING KEYS TO LONG
            for (int i = 0; i < keyarray.length; i++) {
                longkeyarray[i] = Long.parseLong(keyarray[i], 16);
            }
            long temp;
            String stemp;

            //SORTING IP, KEY AND PORT IN ASCENDING KEYS
            for (int i = 0; i < keyarray.length; i++) {
                for (int k = (i + 1); k < keyarray.length; k++) {
                    if (longkeyarray[i] > longkeyarray[k]) {
                        temp = longkeyarray[k];
                        longkeyarray[k] = longkeyarray[i];
                        longkeyarray[i] = temp;

                        stemp = iparray[k];
                        iparray[k] = iparray[i];
                        iparray[i] = stemp;

                        stemp = portarray[k];
                        portarray[k] = portarray[i];
                        portarray[i] = stemp;

                    }
                }
            }

            //for(int i=0;i<keyarray.length;i++){
            //	System.out.println("checking"+longkeyarray[i]+"  "+iparray[i]+" "+portarray[i]);
            //}

            //LOOP TO SELECT THE SUCCESSOR
            if (PeerNum == 0) {
                System.out.println("No nodes in network");
                successor = mynodenum;
                successorip = sysaddr;
                successorport = PortNumber;
                pred = mynodenum;
            } else {
                if (mynodenum > longkeyarray[longkeyarray.length - 1]) {
                    successor = longkeyarray[0];
                    successorip = iparray[0];
                    successorport = Integer.parseInt(portarray[0]);
                } else {
                    for (int i = 0; i < (keyarray.length); i++) {
                        if (i != 0) {
                            if (longkeyarray[i] > mynodenum && longkeyarray[i - 1] < mynodenum) {
                                successor = longkeyarray[i];
                                successorip = iparray[i];
                                successorport = Integer.parseInt(portarray[i]);
                            }
                        } else {
                            if (longkeyarray[i] > mynodenum) {
                                successor = longkeyarray[0];
                                successorip = iparray[i];
                                successorport = Integer.parseInt(portarray[i]);
                            }
                        }
                    }


                }
                System.out.println("checking" + successorip + " " + successorport);

                //LOOP TO SELECT THE PREDESSOR
                if (mynodenum < longkeyarray[0]) {
                    pred = longkeyarray[longkeyarray.length - 1];
                } else {
                    for (int i = 0; i < (keyarray.length); i++) {
                        if (i != 0 && i < keyarray.length - 1) {
                            if (longkeyarray[i] < mynodenum && longkeyarray[i + 1] > mynodenum) {
                                pred = longkeyarray[i];
                            }
                        } else if (i == 0) {
                            if (longkeyarray[i] < mynodenum) {
                                pred = longkeyarray[0];
                            }
                        } else if (i == keyarray.length - 1) {
                            if (longkeyarray[i] < mynodenum) {
                                pred = longkeyarray[i];
                            }
                        }
                    }
                }
                System.out.println("successor :" + successor);
                System.out.println("predessor :" + pred);

            }
            hashsuccessor(sen);
            keytable();

            System.out.println("Sending UPFIN to nodes");
            for (int i = 0; i < PeerNum; i++) {
                String ss = "0028 UPFIN 0 " + sysaddr + " " + PortNumber + " " + mynodenum;
                //length UPFIN type IP port key
                NodeclientSocket = new Socket(InetAddress.getByName(iparray[i]), Integer.parseInt(portarray[i]));
                PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                PS.println(ss);
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                String clientSentence = inFromClient.readLine();
                System.out.println("Message received : " + clientSentence);
                String[] splitcmd1 = clientSentence.split(" ");
                if (splitcmd1[2].equals("0")) {
                    System.out.println("Successful");
                } else {
                    System.out.println("Error");
                }
            }

            if (PeerNum != 0) {
                System.out.println("Sending getky");
                String sentence = "GETKY " + syskey;
                sentence = "00" + sentence.length() + " " + sentence;
                System.out.println(sentence);
                //sender(successorip,successorport,sentence);
                NodeclientSocket = new Socket(successorip, successorport);
                PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                PS.println(sentence);
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                String clientSentence = inFromClient.readLine();
                System.out.println("Message received : " + clientSentence);
                getkyokreceived(clientSentence);
            }
        }

    }

    //********************************************************************************
    //FUNCTION TO RANDOMLY PICK 5 FILES FOR SERVER
    public static String[] getmyfiles() throws Exception {
        int n = 20;
        if (inNetwork < 20) {
            n = 20;
        } else if (inNetwork >= 20 && inNetwork < 40) {
            n = 40;
        } else if (inNetwork >= 40 && inNetwork < 60) {
            n = 60;
        } else if (inNetwork >= 60) {
            n = 80;
        }
        String path = "filenames.txt";
        int counter = 1, j = 0, i, k;
        FileReader fr = new FileReader(path);
        BufferedReader textReader = new BufferedReader(fr);

        Random randomInt = new Random();
        int[] randomNumber = new int[5];
        for (i = 0; i < 5; i++) {
            randomNumber[i] = randomInt.nextInt(n) + 1;
        }

        for (i = 0; i < 5; i++) {
            for (k = (i + 1); k < 5; k++) {
                if (randomNumber[i] == randomNumber[k]) {
                    randomNumber[i]++;
                    i = 0;
                }
            }
        }


        String temp;
        while ((temp = textReader.readLine()) != null) {
            if (counter == randomNumber[0] || counter == randomNumber[1] || counter == randomNumber[2] || counter == randomNumber[3] || counter == randomNumber[4]) {
                myfiles[j] = temp;
                j++;

            }
            counter++;
        }
        textReader.close();
        return (myfiles);
    }


    //**************FUNTION IF ADD IS RECEIVED***********************
    public static void addreceived(String sen) throws Exception {
        String[] split = sen.split(" ");
        ArrayList<String> filesinmap = new ArrayList<String>();
        String ip = split[2], port = split[3], file = split[5];
        long keytoken = Long.parseLong(split[4], 16);
        System.out.println("adding to keytable");
        filesinmap = new ArrayList<String>();
        if (keytablefile.get(keytoken) != null) {
            filesinmap = keytablefile.get(keytoken);
        }
        filesinmap.add(file);
        keytablekey.add(keytoken);
        keytableip.put(keytoken, ip);
        keytableport.put(keytoken, Integer.parseInt(port));
        keytablefile.put(keytoken, filesinmap);
        //NodeclientSocket = new Socket(ip,Integer.parseInt(port));
        PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
        String rep = "0012 ADDOK 0";
        PS.println(rep);
        NodeclientSocket.close();
    }

    //**********************TO CREATE THE KEY TABLE***********************
    public static void keytable() throws Exception {
        //convert all filenames to hash and add to key table after tokenizing
        //what if no new node comes into the network, then we have to send the keys on our own right?
        System.out.println("creating key table");
        ArrayList<String> filesinmap = new ArrayList<String>();
        String token;
        long keytoken;
        //store all keys in self key table
        for (int i = 0; i < 5; i++) {
            String[] splithashfiles = myfiles[i].split(" ");
            for (int j = 0; j < splithashfiles.length; j++) {
                token = splithashfiles[j];

                keytoken = Long.parseLong(Myhash(token), 16);
                if (keytoken < mynodenum && keytoken > pred || PeerNum == 0) {
                    filesinmap = new ArrayList<String>();
                    if (keytablefile.get(keytoken) != null) {
                        filesinmap = keytablefile.get(keytoken);
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablefile.put(keytoken, filesinmap);
                    } else {
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablekey.add(keytoken);
                        keytableip.put(keytoken, sysaddr);
                        keytableport.put(keytoken, PortNumber);
                        keytablefile.put(keytoken, filesinmap);
                    }
                } else {
                    //send ADD to successor
                    System.out.println("Sendind add to successor of key");
                    String sentence = "ADD " + sysaddr + " " + PortNumber + " " + keytoken + " " + token;
                    sentence = "00" + sentence.length() + " " + sentence;
                    //SEND TO SUCCESSOR
                    //sender(successorip,successorport,sentence);
                    for (int p = 1; p < 32; p++) {
                        String interval = hashinterval.get(fingers[p]);
                        String[] mm = interval.split(",");
                        if (keytoken > Long.parseLong(mm[0]) && keytoken < Long.parseLong(mm[1].trim())) {
                            String[] iport = (hashssriport.get(hashssr.get(fingers[p]))).split("_");
                            System.out.println(iport[0] + "   " + Integer.parseInt(iport[1]));
                            NodeclientSocket = new Socket(iport[0], Integer.parseInt(iport[1]));
                            PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                            PS.println(sentence);
                            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                            String clientSentence = inFromClient.readLine();
                            System.out.println("Message received : " + clientSentence);
                            String[] splitcmd = clientSentence.split(" ");
                            splitcmd[2] = splitcmd[2].trim();
                            if (splitcmd[2].equals("0")) {
                                System.out.println("ADD successful");
                            } else if (splitcmd[2].equals("9998")) {
                                System.out.println("error while adding");
                            } else {
                                System.out.println("Peer unreachable. Error");
                            }
                        }
                    }
                }
            }
            for (int j = 1; j < splithashfiles.length; j++) {
                token = splithashfiles[j - 1] + "_" + splithashfiles[j];
                keytoken = Long.parseLong(Myhash(token), 16);
                if (keytoken < mynodenum && keytoken > pred || PeerNum == 0) {
                    filesinmap = new ArrayList<String>();
                    if (keytablefile.get(keytoken) != null) {
                        filesinmap = keytablefile.get(keytoken);
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablefile.put(keytoken, filesinmap);
                    } else {
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablekey.add(keytoken);
                        keytableip.put(keytoken, sysaddr);
                        keytableport.put(keytoken, PortNumber);
                        keytablefile.put(keytoken, filesinmap);
                    }
                } else {
                    //send ADD to successor
                    System.out.println("Sendind add to successor of key");
                    String sentence = "ADD " + sysaddr + " " + PortNumber + " " + keytoken + " " + token;
                    sentence = "00" + sentence.length() + " " + sentence;
                    //SEND TO SUCCESSOR
                    //sender(successorip,successorport,sentence);
                    for (int p = 1; p < 32; p++) {
                        String interval = hashinterval.get(fingers[p]);
                        String[] mm = interval.split(",");
                        if (keytoken > Long.parseLong(mm[0]) && keytoken < Long.parseLong(mm[1].trim())) {
                            String[] iport = (hashssriport.get(hashssr.get(fingers[p]))).split("_");
                            System.out.println(iport[0] + "   " + Integer.parseInt(iport[1]));
                            NodeclientSocket = new Socket(iport[0], Integer.parseInt(iport[1]));
                            PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                            PS.println(sentence);
                            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                            String clientSentence = inFromClient.readLine();
                            System.out.println("Message received : " + clientSentence);
                            String[] splitcmd = clientSentence.split(" ");
                            splitcmd[2] = splitcmd[2].trim();
                            if (splitcmd[2].equals("0")) {
                                System.out.println("ADD successful");
                            } else if (splitcmd[2].equals("9998")) {
                                System.out.println("error while adding");
                            } else {
                                System.out.println("Peer unreachable. Error");
                            }
                        }
                    }
                }

            }
            for (int j = 2; j < splithashfiles.length; j++) {
                token = splithashfiles[j - 2] + "_" + splithashfiles[j - 1] + "_" + splithashfiles[j];
                keytoken = Long.parseLong(Myhash(token), 16);
                if (keytoken < mynodenum && keytoken > pred || PeerNum == 0) {
                    filesinmap = new ArrayList<String>();
                    if (keytablefile.get(keytoken) != null) {
                        filesinmap = keytablefile.get(keytoken);
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablefile.put(keytoken, filesinmap);
                    } else {
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablekey.add(keytoken);
                        keytableip.put(keytoken, sysaddr);
                        keytableport.put(keytoken, PortNumber);
                        keytablefile.put(keytoken, filesinmap);
                    }
                } else {
                    //send ADD to successor
                    System.out.println("Sendind add to successor of key");
                    String sentence = "ADD " + sysaddr + " " + PortNumber + " " + keytoken + " " + token;
                    sentence = "00" + sentence.length() + " " + sentence;
                    //SEND TO SUCCESSOR
                    //sender(successorip,successorport,sentence);
                    for (int p = 1; p < 32; p++) {
                        String interval = hashinterval.get(fingers[p]);
                        String[] mm = interval.split(",");
                        if (keytoken > Long.parseLong(mm[0]) && keytoken < Long.parseLong(mm[1].trim())) {
                            String[] iport = (hashssriport.get(hashssr.get(fingers[p]))).split("_");
                            System.out.println(iport[0] + "   " + Integer.parseInt(iport[1]));
                            NodeclientSocket = new Socket(iport[0], Integer.parseInt(iport[1]));
                            PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                            PS.println(sentence);
                            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                            String clientSentence = inFromClient.readLine();
                            System.out.println("Message received : " + clientSentence);
                            String[] splitcmd = clientSentence.split(" ");
                            splitcmd[2] = splitcmd[2].trim();
                            if (splitcmd[2].equals("0")) {
                                System.out.println("ADD successful");
                            } else if (splitcmd[2].equals("9998")) {
                                System.out.println("error while adding");
                            } else {
                                System.out.println("Peer unreachable. Error");
                            }
                        }
                    }
                }
            }
            for (int j = 3; j < splithashfiles.length; j++) {
                token = splithashfiles[j - 3] + "_" + splithashfiles[j - 2] + "_" + splithashfiles[j - 1] + "_" + splithashfiles[j];
                keytoken = Long.parseLong(Myhash(token), 16);
                if (keytoken < mynodenum && keytoken > pred || PeerNum == 0) {
                    filesinmap = new ArrayList<String>();
                    if (keytablefile.get(keytoken) != null) {
                        filesinmap = keytablefile.get(keytoken);
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablefile.put(keytoken, filesinmap);
                    } else {
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablekey.add(keytoken);
                        keytableip.put(keytoken, sysaddr);
                        keytableport.put(keytoken, PortNumber);
                        keytablefile.put(keytoken, filesinmap);
                    }
                } else {
                    //send ADD to successor
                    System.out.println("Sendind add to successor of key");
                    String sentence = "ADD " + sysaddr + " " + PortNumber + " " + keytoken + " " + token;
                    sentence = "00" + sentence.length() + " " + sentence;
                    //SEND TO SUCCESSOR
                    //sender(successorip,successorport,sentence);
                    for (int p = 1; p < 32; p++) {
                        String interval = hashinterval.get(fingers[p]);
                        String[] mm = interval.split(",");
                        if (keytoken > Long.parseLong(mm[0]) && keytoken < Long.parseLong(mm[1].trim())) {
                            String[] iport = (hashssriport.get(hashssr.get(fingers[p]))).split("_");
                            System.out.println(iport[0] + "   " + Integer.parseInt(iport[1]));
                            NodeclientSocket = new Socket(iport[0], Integer.parseInt(iport[1]));
                            PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                            PS.println(sentence);
                            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                            String clientSentence = inFromClient.readLine();
                            System.out.println("Message received : " + clientSentence);
                            String[] splitcmd = clientSentence.split(" ");
                            splitcmd[2] = splitcmd[2].trim();
                            if (splitcmd[2].equals("0")) {
                                System.out.println("ADD successful");
                            } else if (splitcmd[2].equals("9998")) {
                                System.out.println("error while adding");
                            } else {
                                System.out.println("Peer unreachable. Error");
                            }
                        }
                    }
                }
            }
            for (int j = 4; j < splithashfiles.length; j++) {
                token = splithashfiles[j - 4] + "_" + splithashfiles[j - 3] + "_" + splithashfiles[j - 2] + "_" + splithashfiles[j - 1] + "_" + splithashfiles[j];
                keytoken = Long.parseLong(Myhash(token), 16);
                if (keytoken < mynodenum && keytoken > pred || PeerNum == 0) {
                    filesinmap = new ArrayList<String>();
                    if (keytablefile.get(keytoken) != null) {
                        filesinmap = keytablefile.get(keytoken);
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablefile.put(keytoken, filesinmap);
                    } else {
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablekey.add(keytoken);
                        keytableip.put(keytoken, sysaddr);
                        keytableport.put(keytoken, PortNumber);
                        keytablefile.put(keytoken, filesinmap);
                    }
                } else {
                    //send ADD to successor
                    System.out.println("Sendind add to successor of key");
                    String sentence = "ADD " + sysaddr + " " + PortNumber + " " + keytoken + " " + token;
                    sentence = "00" + sentence.length() + " " + sentence;
                    //SEND TO SUCCESSOR
                    //sender(successorip,successorport,sentence);
                    for (int p = 1; p < 32; p++) {
                        String interval = hashinterval.get(fingers[p]);
                        String[] mm = interval.split(",");
                        if (keytoken > Long.parseLong(mm[0]) && keytoken < Long.parseLong(mm[1].trim())) {
                            String[] iport = (hashssriport.get(hashssr.get(fingers[p]))).split("_");
                            System.out.println(iport[0] + "   " + Integer.parseInt(iport[1]));
                            NodeclientSocket = new Socket(iport[0], Integer.parseInt(iport[1]));
                            PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                            PS.println(sentence);
                            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                            String clientSentence = inFromClient.readLine();
                            System.out.println("Message received : " + clientSentence);
                            String[] splitcmd = clientSentence.split(" ");
                            splitcmd[2] = splitcmd[2].trim();
                            if (splitcmd[2].equals("0")) {
                                System.out.println("ADD successful");
                            } else if (splitcmd[2].equals("9998")) {
                                System.out.println("error while adding");
                            } else {
                                System.out.println("Peer unreachable. Error");
                            }
                        }
                    }
                }
            }
            for (int j = 5; j < splithashfiles.length; j++) {
                token = splithashfiles[j - 5] + "_" + splithashfiles[j - 4] + "_" + splithashfiles[j - 3] + "_" + splithashfiles[j - 2] + "_" + splithashfiles[j - 1] + "_" + splithashfiles[j];
                keytoken = Long.parseLong(Myhash(token), 16);
                if (keytoken < mynodenum && keytoken > pred || PeerNum == 0) {
                    filesinmap = new ArrayList<String>();
                    if (keytablefile.get(keytoken) != null) {
                        filesinmap = keytablefile.get(keytoken);
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablefile.put(keytoken, filesinmap);
                    } else {
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablekey.add(keytoken);
                        keytableip.put(keytoken, sysaddr);
                        keytableport.put(keytoken, PortNumber);
                        keytablefile.put(keytoken, filesinmap);
                    }
                } else {
                    //send ADD to successor
                    System.out.println("Sendind add to successor of key");
                    String sentence = "ADD " + sysaddr + " " + PortNumber + " " + keytoken + " " + token;
                    sentence = "00" + sentence.length() + " " + sentence;
                    //SEND TO SUCCESSOR
                    //sender(successorip,successorport,sentence);
                    for (int p = 1; p < 32; p++) {
                        String interval = hashinterval.get(fingers[p]);
                        String[] mm = interval.split(",");
                        if (keytoken > Long.parseLong(mm[0]) && keytoken < Long.parseLong(mm[1].trim())) {
                            String[] iport = (hashssriport.get(hashssr.get(fingers[p]))).split("_");
                            System.out.println(iport[0] + "   " + Integer.parseInt(iport[1]));
                            NodeclientSocket = new Socket(iport[0], Integer.parseInt(iport[1]));
                            PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                            PS.println(sentence);
                            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                            String clientSentence = inFromClient.readLine();
                            System.out.println("Message received : " + clientSentence);
                            String[] splitcmd = clientSentence.split(" ");
                            splitcmd[2] = splitcmd[2].trim();
                            if (splitcmd[2].equals("0")) {
                                System.out.println("ADD successful");
                            } else if (splitcmd[2].equals("9998")) {
                                System.out.println("error while adding");
                            } else {
                                System.out.println("Peer unreachable. Error");
                            }
                        }
                    }
                }
            }
            for (int j = 6; j < splithashfiles.length; j++) {
                token = splithashfiles[j - 6] + "_" + splithashfiles[j - 5] + "_" + splithashfiles[j - 4] + "_" + splithashfiles[j - 3] + "_" + splithashfiles[j - 2] + "_" + splithashfiles[j - 1] + "_" + splithashfiles[j];
                keytoken = Long.parseLong(Myhash(token), 16);
                if (keytoken < mynodenum && keytoken > pred || PeerNum == 0) {
                    filesinmap = new ArrayList<String>();
                    if (keytablefile.get(keytoken) != null) {
                        filesinmap = keytablefile.get(keytoken);
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablefile.put(keytoken, filesinmap);
                    } else {
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablekey.add(keytoken);
                        keytableip.put(keytoken, sysaddr);
                        keytableport.put(keytoken, PortNumber);
                        keytablefile.put(keytoken, filesinmap);
                    }
                } else {
                    //send ADD to successor
                    System.out.println("Sendind add to successor of key");
                    String sentence = "ADD " + sysaddr + " " + PortNumber + " " + keytoken + " " + token;
                    sentence = "00" + sentence.length() + " " + sentence;
                    //SEND TO SUCCESSOR
                    //sender(successorip,successorport,sentence);
                    for (int p = 1; p < 32; p++) {
                        String interval = hashinterval.get(fingers[p]);
                        String[] mm = interval.split(",");
                        if (keytoken > Long.parseLong(mm[0]) && keytoken < Long.parseLong(mm[1].trim())) {
                            String[] iport = (hashssriport.get(hashssr.get(fingers[p]))).split("_");
                            System.out.println(iport[0] + "   " + Integer.parseInt(iport[1]));
                            NodeclientSocket = new Socket(iport[0], Integer.parseInt(iport[1]));
                            PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                            PS.println(sentence);
                            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                            String clientSentence = inFromClient.readLine();
                            System.out.println("Message received : " + clientSentence);
                            String[] splitcmd = clientSentence.split(" ");
                            splitcmd[2] = splitcmd[2].trim();
                            if (splitcmd[2].equals("0")) {
                                System.out.println("ADD successful");
                            } else if (splitcmd[2].equals("9998")) {
                                System.out.println("error while adding");
                            } else {
                                System.out.println("Peer unreachable. Error");
                            }
                        }
                    }
                }
            }
            for (int j = 7; j < splithashfiles.length; j++) {
                token = splithashfiles[j - 7] + "_" + splithashfiles[j - 6] + "_" + splithashfiles[j - 5] + "_" + splithashfiles[j - 4] + "_" + splithashfiles[j - 3] + "_" + splithashfiles[j - 2] + "_" + splithashfiles[j - 1] + "_" + splithashfiles[j];
                keytoken = Long.parseLong(Myhash(token), 16);
                if (keytoken < mynodenum && keytoken > pred || PeerNum == 0) {
                    filesinmap = new ArrayList<String>();
                    if (keytablefile.get(keytoken) != null) {
                        filesinmap = keytablefile.get(keytoken);
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablefile.put(keytoken, filesinmap);
                    } else {
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablekey.add(keytoken);
                        keytableip.put(keytoken, sysaddr);
                        keytableport.put(keytoken, PortNumber);
                        keytablefile.put(keytoken, filesinmap);
                    }
                } else {
                    //send ADD to successor
                    System.out.println("Sendind add to successor of key");
                    String sentence = "ADD " + sysaddr + " " + PortNumber + " " + keytoken + " " + token;
                    sentence = "00" + sentence.length() + " " + sentence;
                    //SEND TO SUCCESSOR
                    //sender(successorip,successorport,sentence);
                    for (int p = 1; p < 32; p++) {
                        String interval = hashinterval.get(fingers[p]);
                        String[] mm = interval.split(",");
                        if (keytoken > Long.parseLong(mm[0]) && keytoken < Long.parseLong(mm[1].trim())) {
                            String[] iport = (hashssriport.get(hashssr.get(fingers[p]))).split("_");
                            System.out.println(iport[0] + "   " + Integer.parseInt(iport[1]));
                            NodeclientSocket = new Socket(iport[0], Integer.parseInt(iport[1]));
                            PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                            PS.println(sentence);
                            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                            String clientSentence = inFromClient.readLine();
                            System.out.println("Message received : " + clientSentence);
                            String[] splitcmd = clientSentence.split(" ");
                            splitcmd[2] = splitcmd[2].trim();
                            if (splitcmd[2].equals("0")) {
                                System.out.println("ADD successful");
                            } else if (splitcmd[2].equals("9998")) {
                                System.out.println("error while adding");
                            } else {
                                System.out.println("Peer unreachable. Error");
                            }
                        }
                    }
                }
            }
            for (int j = 8; j < splithashfiles.length; j++) {
                token = splithashfiles[j - 8] + "_" + splithashfiles[j - 7] + "_" + splithashfiles[j - 6] + "_" + splithashfiles[j - 5] + "_" + splithashfiles[j - 4] + "_" + splithashfiles[j - 3] + "_" + splithashfiles[j - 2] + "_" + splithashfiles[j - 1] + "_" + splithashfiles[j];
                keytoken = Long.parseLong(Myhash(token), 16);
                if (keytoken < mynodenum && keytoken > pred || PeerNum == 0) {
                    filesinmap = new ArrayList<String>();
                    if (keytablefile.get(keytoken) != null) {
                        filesinmap = keytablefile.get(keytoken);
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablefile.put(keytoken, filesinmap);
                    } else {
                        String xx = "";
                        for (int x = 0; x < splithashfiles.length; x++) {
                            xx = xx + splithashfiles[x] + "_";
                        }
                        filesinmap.add(xx);
                        keytablekey.add(keytoken);
                        keytableip.put(keytoken, sysaddr);
                        keytableport.put(keytoken, PortNumber);
                        keytablefile.put(keytoken, filesinmap);
                    }
                } else {
                    //send ADD to successor
                    System.out.println("Sendind add to successor of key");
                    String sentence = "ADD " + sysaddr + " " + PortNumber + " " + keytoken + " " + token;
                    sentence = "00" + sentence.length() + " " + sentence;
                    //SEND TO SUCCESSOR
                    //sender(successorip,successorport,sentence);
                    for (int p = 1; p < 32; p++) {
                        String interval = hashinterval.get(fingers[p]);
                        String[] mm = interval.split(",");
                        if (keytoken > Long.parseLong(mm[0]) && keytoken < Long.parseLong(mm[1].trim())) {
                            String[] iport = (hashssriport.get(hashssr.get(fingers[p]))).split("_");
                            System.out.println(iport[0] + "   " + Integer.parseInt(iport[1]));
                            NodeclientSocket = new Socket(iport[0], Integer.parseInt(iport[1]));
                            PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                            PS.println(sentence);
                            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                            String clientSentence = inFromClient.readLine();
                            System.out.println("Message received : " + clientSentence);
                            String[] splitcmd = clientSentence.split(" ");
                            splitcmd[2] = splitcmd[2].trim();
                            if (splitcmd[2].equals("0")) {
                                System.out.println("ADD successful");
                            } else if (splitcmd[2].equals("9998")) {
                                System.out.println("error while adding");
                            } else {
                                System.out.println("Peer unreachable. Error");
                            }
                        }
                    }
                }
            }
        }
    }


    //TO SEND KEYS TO THE NEW NODE
    public static void getkyokreceived(String sentence) {
        //check key table and send all keys that have value lower than the key received
        //add all keys in key table

        String[] split = sentence.split(" ");
        int noofkeys = Integer.parseInt(split[2]);
        if (noofkeys == 9999) {
            System.out.println("Error.");
        } else if (noofkeys == 0) {
            System.out.println("No keys to return");
        } else {
            System.out.println("Successful");
            String[] ip = new String[noofkeys];
            int[] port = new int[noofkeys];
            long[] key = new long[noofkeys];
            String[] files = new String[noofkeys];

            int j = 3;
            for (int i = 0; i < noofkeys; i++) {
                ip[i] = split[j];
                j++;
                port[i] = Integer.parseInt(split[j]);
                j++;
                key[i] = Long.parseLong(split[j]);
                j++;
                files[i] = split[j];
                j++;
            }
            ArrayList<String> list = new ArrayList<String>();
            int g = 0;
            for (int k = 0; k < noofkeys; k++) {
                for (int i = 0; i < keytablekey.size(); i++) {
                    if (key[k] == keytablekey.get(i)) {
                        g = 1;
                    }
                }
                if (g == 1) {
                    list = new ArrayList<String>();
                    list = keytablefile.get(key[k]);
                    list.add(files[k]);
                    keytablefile.put(key[k], list);
                    g = 0;
                } else {
                    list = new ArrayList<String>();
                    list.add(files[k]);
                    keytablefile.put(key[k], list);
                    keytablekey.add(key[k]);
                    keytableip.put(key[k], ip[k]);
                    keytableport.put(key[k], port[k]);
                }
            }

            System.out.println(keytablefile + "\n" + keytableport + "\n" + keytableip);
        }
    }

    //TO SEND KEYS BEFORE LEAVING THE NETWORK
    public static void givekey() throws Exception {
        //send all keys in key table to successor

        String sentence = "GIVEKY " + keytablekey.size();
        for (int i = 0; i < keytablekey.size(); i++) {
            String key1 = keytablefile.get(keytablekey.get(i)).toString();
            key1 = key1.replace("[", "");
            key1 = key1.replace("]", "");
            sentence = sentence + " " + keytableip.get(keytablekey.get(i)) + " " + keytableport.get(keytablekey.get(i)) + " " + keytablekey.get(i) + " " + key1;
        }
        keytableip.clear();
        keytablekey.clear();
        keytableport.clear();
        keytablefile.clear();
        System.out.println(keytablefile + "\n" + keytableport + "\n" + keytableip);
        sentence = "0" + sentence.length() + " " + sentence;
        System.out.println(sentence);

        NodeclientSocket = new Socket(successorip, successorport);
        PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
        PS.println(sentence);
        BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
        String clientSentence = inFromClient.readLine();
        System.out.println("Message received : " + clientSentence);
        String[] splitcmd = clientSentence.split(" ");
        splitcmd[2] = splitcmd[2].trim();
        if (splitcmd[2].equals("0")) {
            System.out.println("keys successfully given to successor");
        } else if (splitcmd[2].equals("9998")) {
            System.out.println("error while giving");
        } else {
            System.out.println("Error in command");
        }

    }

    public static void getkeyreceived(String sentence) throws Exception {
        //send all keys in key table to successor
        String[] split = sentence.split(" ");
        long key = Long.parseLong(split[2].trim(), 16);
        //String sentence = "GETKYOK "+keytablekey.size();
        String sen = "";
        int noofkeys = 0;
        for (int i = 0; i < keytablekey.size(); i++) {
            if (key > keytablekey.get(i)) {
                String key1 = keytablefile.get(keytablekey.get(i)).toString();
                key1 = key1.replace("[", "");
                key1 = key1.replace("]", "");
                key1 = key1.replace(" ", "_");
                sen = sen + " " + keytableip.get(keytablekey.get(i)) + " " + keytableport.get(keytablekey.get(i)) + " " + keytablekey.get(i) + " " + key1;
                noofkeys++;
                keytableip.remove(i);
                keytablekey.remove(i);
                keytableport.remove(i);
                keytablefile.remove(i);
            }
        }
        sen = "GETKYOK " + noofkeys + sen;
        //System.out.println(keytablefile+"\n"+keytableport+"\n"+keytableip);
        sen = "0" + sentence.length() + " " + sen;
        System.out.println(sen);

        //NodeclientSocket = new Socket(successorip,successorport);
        PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
        PS.println(sen);
    }


    public static void getkeyokreceived(String sentence) throws Exception {
        //add all keys in key table

        String[] split = sentence.split(" ");
        int noofkeys = Integer.parseInt(split[2]);
        String[] ip = new String[noofkeys];
        int[] port = new int[noofkeys];
        long[] key = new long[noofkeys];
        String[] files = new String[noofkeys];

        int j = 3;
        for (int i = 0; i < noofkeys; i++) {
            ip[i] = split[j];
            j++;
            port[i] = Integer.parseInt(split[j]);
            j++;
            key[i] = Long.parseLong(split[j]);
            j++;
            files[i] = split[j];
            j++;
        }
        ArrayList<String> list = new ArrayList<String>();
        int g = 0;
        for (int k = 0; k < noofkeys; k++) {
            for (int i = 0; i < keytablekey.size(); i++) {
                if (key[k] == keytablekey.get(i)) {
                    g = 1;
                }
            }
            if (g == 1) {
                list = new ArrayList<String>();
                list = keytablefile.get(key[k]);
                list.add(files[k]);
                keytablefile.put(key[k], list);
                g = 0;
            } else {
                list = new ArrayList<String>();
                list.add(files[k]);
                keytablefile.put(key[k], list);
                keytablekey.add(key[k]);
                keytableip.put(key[k], ip[k]);
                keytableport.put(key[k], port[k]);
            }
        }
    }

    //TO ACCEPT KEYS IF AN OTHER NODE IS LEAVING THE NETWORK
    public static void givekeyreceived(String sentence) throws Exception {
        //add all keys in key table

        String[] split = sentence.split(" ");
        int noofkeys = Integer.parseInt(split[2]);
        String[] ip = new String[noofkeys];
        int[] port = new int[noofkeys];
        long[] key = new long[noofkeys];
        String[] files = new String[noofkeys];

        int j = 3;
        for (int i = 0; i < noofkeys; i++) {

            ip[i] = split[j];
            System.out.println(split[j]);
            j++;
            port[i] = Integer.parseInt(split[j]);
            System.out.println(split[j]);
            j++;
            key[i] = Long.parseLong(split[j]);
            System.out.println(split[j]);
            j++;
            files[i] = split[j];
            System.out.println(split[j]);
            j++;
        }
        ArrayList<String> list = new ArrayList<String>();
        int g = 0;
        for (int k = 0; k < noofkeys; k++) {
            for (int i = 0; i < keytablekey.size(); i++) {
                if (key[k] == keytablekey.get(i)) {
                    g = 1;
                }
            }
            if (g == 1) {
                list = new ArrayList<String>();
                list = keytablefile.get(key[k]);
                list.add(files[k]);
                keytablefile.put(key[k], list);
                g = 0;
            } else {
                list = new ArrayList<String>();
                list.add(files[k]);
                keytablefile.put(key[k], list);
                keytablekey.add(key[k]);
                keytableip.put(key[k], ip[k]);
                keytableport.put(key[k], port[k]);
            }
        }
        String sen = "GIVEKYOK 0";
        sentence = "00" + sentence.length() + " " + sen;
        System.out.println(sen);

        NodeclientSocket = new Socket(successorip, successorport);
        PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
        PS.println(sen);

        System.out.println(keytablefile + "\n" + keytableport + "\n" + keytableip);
    }

    public static void sender(String address, int port, String sen) throws Exception {

        NodeclientSocket = new Socket(InetAddress.getByName(address), port);
        PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
        PS.println(sen);
        //PS.close();
        //BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
        //String clientSentence =inFromClient.readLine();
        //System.out.println("Message received 1 : "+clientSentence);
        //NodeclientSocket.setSoTimeout(1000);
        //NodeclientSocket.close();
    }

    //*******FUNCTION TO UPDATE FINGERTABLE (UPFIN)***********
    public static void UPFIN0(String sen) throws Exception {
        int g = 1;
        String[] splitcmd = sen.split(" ");
        long key = Long.parseLong(splitcmd[5].trim());
        String port = splitcmd[4];
        String ip = splitcmd[3];

        if (key > mynodenum && key < successor) {
            successor = key;
            successorip = ip;
            successorport = Integer.parseInt(port);
        }

        hashssriport.put(key, ip + "_" + port);

        //LOOP TO CHECK IF SUCCESSOR IS EQUAL TO FINGER.
        for (int p = 1; p <= m; p++) {
            if (fingers[p] == key) {
                g = 0;
            }
            if (g == 0) {
                hashssr.put(fingers[p], fingers[p]);
                g = 1;
            }
        }

        System.out.println("check if not equal to key");
        //ASSIGNING SUCCESSOR IF SUCCESSOR IS NOT EQUAL TO FINGER
        for (int p = 1; p <= m; p++) {
            long succ = hashssr.get(fingers[p]);
            long ltemp = 0L;
            if (key == 0 || (key < fingers[p])) {
                ltemp = key;
                key += (long) Math.pow(2, m);
            }
            succ = hashssr.get(fingers[p]);
            if (succ < fingers[p]) {
                succ += (long) Math.pow(2, m);
            }
            if (key > fingers[p] && key < succ) {
                if (key == (int) Math.pow(2, m) || key == (int) Math.pow(2, m) + ltemp) {
                    key = ltemp;
                }
                hashssr.put(fingers[p], key);

                //System.out.println(hashssr);
            }
            if (key == (int) Math.pow(2, m) || key == (int) Math.pow(2, m) + ltemp) {
                key = ltemp;
            }

            if (p < m && succ != fingers[p] && hashssr.get(fingers[p + 1]) == fingers[p + 1] && hashssr.get(fingers[p + 1]) < succ) {
                hashssr.put(fingers[p], hashssr.get(fingers[p + 1]));
                //System.out.println(hashssr);
            }
        }

        for (int p = 1; p <= m; p++) {
            if (hashssr.get(fingers[p]) == key) {
                hashssriport.put(key, ip + "_" + port);
            }
        }
        PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
        String rep = "0012 UPFINOK 0";
        PS.println(rep);
        NodeclientSocket.close();

    }

    //*******UPFIN1*****************
    public static void UPFIN1(String sen) {
        //length UPFIN 1 IP port key
        String[] splitcmd = sen.split(" ");
        long key = Long.parseLong(splitcmd[5].trim());
        String port = splitcmd[4];
        String ip = splitcmd[3];

        for (int p = 1; p <= m; p++) {
            if (p < m) {
                if (hashssr.get(fingers[p]) == key) {
                    hashssr.put(fingers[p], hashssr.get(fingers[p + 1]));
                }

            } else {
                if (hashssr.get(fingers[p]) == key) {
                    hashssr.put(fingers[p], hashssr.get(fingers[1]));
                }
            }
        }
    }

    //****************************************************************
    //PICK FILENAMES TO QUERY
    public static void getqueryfiles() throws Exception {
        int counter = 0;
        queryfiles = new String[60];
        String path = "queries.txt";
        FileReader fr = new FileReader(path);
        BufferedReader textReader = new BufferedReader(fr);
        String temp;
        while (counter < 60) {
            temp = textReader.readLine();
            queryfiles[counter] = temp;
            //System.out.println(queryfiles[counter]);
            counter++;
        }
        textReader.close();
    }

    //**********SEARCH************
    public static void search() throws Exception {
        for (int i = 0; i < 20; i++) {
            long kfile = Long.parseLong(Myhash(queryfiles[i]), 16);
            String sentence = "SER " + sysaddr + " " + PortNumber + " " + kfile + " 0";
            sentence = "00" + sentence.length() + " " + sentence;
            for (int p = 1; p < 32; p++) {
                String interval = hashinterval.get(fingers[p]);
                String[] mm = interval.split(",");
                if (kfile > Long.parseLong(mm[0]) && kfile < Long.parseLong(mm[1].trim())) {
                    String[] iport = (hashssriport.get(hashssr.get(fingers[p]))).split("_");
                    System.out.println("sending search to :" + iport[0] + " " + iport[1]);
                    //sender(iport[0],Integer.parseInt(iport[1]),sentence);
                    NodeclientSocket = new Socket(iport[0], Integer.parseInt(iport[1]));
                    PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                    PS.println(sentence);
                    NodeclientSocket.close();


                    BufferedReader inFromClient = new BufferedReader(new InputStreamReader(NodeclientSocket.getInputStream()));
                    String clientSentence = inFromClient.readLine();
                    System.out.println("Message received : " + clientSentence);
                    String[] splitcmd = clientSentence.split(" ");
                    splitcmd[2] = splitcmd[2].trim();
                    if (splitcmd[2].equals(0)) {
                        System.out.println("Search result: File not found");
                    } else {
                        for (int i1 = 3; i1 < splitcmd.length; i1++) {
                            System.out.println("***************************");
                            System.out.println("IPADDRESS : " + splitcmd[i1]);
                            i1++;
                            System.out.println("PORT : " + splitcmd[i1]);
                            i1++;
                            System.out.println("FILENAME : " + splitcmd[i1]);
                        }


                    }
                }
            }
        }
    }



//**********SEARCHCHECK************
    public static void searchcheck(String sen) throws Exception{
        //length SER IP port key hop
        for(int i=0;i<1000;i++){}
        String[] splitcmd = sen.split(" ");
        int nokey=0,g=1;
        String sentence="";
        ArrayList<String> ip = new ArrayList<String>();ArrayList<Integer> port = new ArrayList<Integer>();ArrayList<String> file = new ArrayList<String>();
        long key = Long.parseLong(splitcmd[4].trim());
        for(int i=0;i<keytablekey.size();i++){
            if(keytablekey.get(i)==key){
                g=0;
                //SEROK no_keys IP1 port1 filename1
                nokey++;
                ip.add(keytableip.get(key));
                port.add(keytableport.get(key));
                file.addAll(keytablefile.get(key));
            }
        }
        if(g==0){
            for(int i=0;i<ip.size();i++){
                sentence = sentence+ip.get(i)+" "+port.get(i)+" "+file.get(i)+" ";
            }

            sentence = "SEROK "+nokey+" "+sentence;
            System.out.println("Sending : "+sentence);
            //sender(splitcmd[2],Integer.parseInt(splitcmd[3]),sentence);
            NodeclientSocket = new Socket(InetAddress.getByName(splitcmd[2]),Integer.parseInt(splitcmd[3]));
            PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
            PS.println(sentence);
            NodeclientSocket.close();
        }
        else{
            System.out.println("forwarding");
            sen = splitcmd[0]+" "+splitcmd[1]+" "+splitcmd[2]+" "+splitcmd[3]+" "+splitcmd[4]+" "+(Integer.parseInt(splitcmd[5])+1);
            for(int p=1;p<32;p++){
                String interval = hashinterval.get(fingers[p]);
                String[] mm = interval.split(",");
                if(key >Long.parseLong(mm[0]) && key<Long.parseLong(mm[1].trim())){
                    System.out.println("interval found");
                    if(hashssr.get(fingers[p]).equals(mynodenum)){
                        System.out.println("here 1?");
                        System.out.println(splitcmd[2]+splitcmd[3]);
                        NodeclientSocket = new Socket(splitcmd[2],Integer.parseInt(splitcmd[3]));
                        PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                        sentence = "0012 SEROK 0";
                        PS.println(sentence);
                        System.out.println("sent");
                        NodeclientSocket.close();
                    }
                    else if(hashssr.get(fingers[p]).equals(""+Long.parseLong(Myhash(splitcmd[2]),16))){
                        System.out.println("here 2?");
                        NodeclientSocket = new Socket(InetAddress.getByName(splitcmd[2]),Integer.parseInt(splitcmd[3]));
                        PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                        sentence = "0012 SEROK 0";
                        PS.println(sentence);
                        NodeclientSocket.close();
                    }
                    else{
                        System.out.println("here 3?");
                        String[] iport = (hashssriport.get(hashssr.get(fingers[p]))).split("_");
                        NodeclientSocket = new Socket(InetAddress.getByName(iport[0]),Integer.parseInt(iport[1]));
                        PrintStream PS = new PrintStream(NodeclientSocket.getOutputStream());
                        PS.println(sen);
                        NodeclientSocket.close();
                    }
                }
            }
        }
    }
}

