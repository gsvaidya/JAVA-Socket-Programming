import BootStrap.sendToBs;
import BootStrap.control;
import ReadMsg.*;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;

/**
 * Created by gandhar on 3/2/16.
 */
public class Main {
    public static void main(String[] args) throws IOException {

        /*int portNum = Integer.parseInt(args[1]);
        InetAddress bootstrapIP = InetAddress.getByName(args[3]);
        int bsPort = Integer.parseInt(args[5]);*/


        readFile r = new readFile("/home/gandhar/lab3/resources.txt");
        String[] resources = r.readFile();
        SimpleFormatter formatter = new SimpleFormatter();


        FileHandler hostLog = new FileHandler("/home/gandhar/lab3/hostName.log");
        hostLog.setFormatter(formatter);


        ArrayList<Node> hostNode = new ArrayList<Node>();
        routingTable tab = new routingTable(hostNode);
        InetAddress bootstrapIP = InetAddress.getByName("129.82.46.205");
        int bsPort = 10000;
        int numberOfNodes = 20;
        DatagramSocket socket = new DatagramSocket(0);
        int portNum = socket.getLocalPort();
        Enumeration e = NetworkInterface.getNetworkInterfaces();
        while (e.hasMoreElements()) {
            NetworkInterface n = (NetworkInterface) e.nextElement();

            InetAddress ip;
            Enumeration ee = n.getInetAddresses();
            while (ee.hasMoreElements()) {
                InetAddress i = (InetAddress) ee.nextElement();

                if (!i.isLoopbackAddress()) {

                    if (i.isSiteLocalAddress()) {

                        // Found non-loopback site-local address. Return it immediately...
                        ip = i;
                        String user = "gandharV";


                        processReq proc = new processReq(numberOfNodes,socket, ip, portNum, user, bootstrapIP, bsPort,resources,tab,hostNode,hostLog);
                        new Thread(proc).start();



                        String ipAddr = ip.toString();

                        String message = CreateMessage.regMsg(ipAddr, portNum, user);
                        sendToBs s = new sendToBs(socket, message, bsPort, bootstrapIP, portNum);
                        s.sendToBootStrap();

                        control usr = new control(socket,ip,portNum,tab,bootstrapIP,user,hostLog);
                        new Thread(usr).start();
                    }

                }
            }

        }

    }
}
