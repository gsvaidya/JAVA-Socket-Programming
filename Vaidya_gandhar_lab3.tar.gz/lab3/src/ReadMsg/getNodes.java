package ReadMsg;

/**
 * Created by gandhar on 3/11/16.
 */
public class getNodes {

    public int getNodes(String msg) {
        String[] s = msg.split(" ");
        Integer numberOfNodes = Integer.valueOf(s[3]);
        return numberOfNodes;
    }
}
