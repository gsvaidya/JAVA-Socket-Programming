package BootStrap;

import ReadMsg.CreateMessage;
import ReadMsg.Node;
import ReadMsg.editAddr;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;

/**
 * Created by gandhar on 3/19/16.
 */
public class leaveDistributedSystem {
    ArrayList<Node> list;
    DatagramSocket socket;
    InetAddress hostIp;
    int hostPort;

    public leaveDistributedSystem(DatagramSocket socket, ArrayList<Node> list, InetAddress hostIp, int hostPort) {
        this.socket = socket;
        this.hostIp = hostIp;
        this.hostPort = hostPort;
        this.list = list;
    }

    public void leave() throws IOException {
        //// leave from the distributed system
        Node n = new Node(hostIp.toString(), hostPort);

        for (int j = 0; j < list.size(); j++) {

            String leaveMsg = CreateMessage.join(false, hostIp.toString(), hostPort);
            String Ip = n.getIp();
            String newIp = editAddr.edit(Ip);

            InetAddress ip = null;
            try {
                ip = InetAddress.getByName(newIp);
            } catch (UnknownHostException un) {
                un.printStackTrace();
            }
            int port = list.get(j).getPort();

            DatagramPacket leavePacket = new DatagramPacket(leaveMsg.getBytes(), leaveMsg.length(), ip, port);
            try {
                socket.send(leavePacket);
            } catch (IOException io) {
                io.printStackTrace();
            }
            String dataSent = new String(leavePacket.getData());
            System.out.println(dataSent + "leave msg flooded in DS at " + port);

        }
    }
}
