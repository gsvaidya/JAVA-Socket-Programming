package BootStrap;

import ReadMsg.CreateMessage;
import ReadMsg.Node;
import ReadMsg.editAddr;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

/**
 * Created by gandhar on 3/20/16.
 */
public class searchDs {
    int numberOfNodes;
    ArrayList<Node> list;
    DatagramSocket socket;
    InetAddress hostIp;
    int hostPort;
    String fname;
    Node newNode;
    Logger logger = Logger.getLogger("Hostname-log");

    public searchDs(int numberOfNodes, DatagramSocket socket, ArrayList<Node> list, InetAddress hostIp, int hostPort, String fname, Node newNode, FileHandler hoST) {
        this.numberOfNodes = numberOfNodes;
        this.socket = socket;
        this.hostIp = hostIp;
        this.hostPort = hostPort;
        this.list = list;
        this.fname = fname;
        this.newNode = newNode;
        logger.addHandler(hoST);

    }


    public void search() {
        Node n = new Node(hostIp.toString(), hostPort);

        for (int j = 0; j < list.size(); j++) {
            System.out.println(fname+"in searChDs");
            String leaveMsg = CreateMessage.search(hostIp.toString(), hostPort, fname, 0);
            String Ip = n.getIp();
            String newIp = editAddr.edit(Ip);

            InetAddress ip = null;
            try {
                ip = InetAddress.getByName(newIp);
            } catch (UnknownHostException un) {
                un.printStackTrace();
            }
            int port = list.get(j).getPort();

            DatagramPacket searchPacket = new DatagramPacket(leaveMsg.getBytes(), leaveMsg.length(), ip, port);
            try {
                socket.send(searchPacket);
            } catch (IOException io) {
                io.printStackTrace();
            }
            String dataSent = new String(searchPacket.getData());
            System.out.println(dataSent + " search msg flooded in DS at " + port);
        }
    }

    public void search2() {
        /*Node n = new Node(hostIp.toString(), hostPort);*/

        String searchMsg = CreateMessage.search(hostIp.toString(), hostPort, fname, 0);
        String Ip = newNode.getIp();
        String newIp = editAddr.edit(Ip);

        InetAddress ip = null;
        try {
            ip = InetAddress.getByName(newIp);
        } catch (UnknownHostException un) {
            un.printStackTrace();
        }
        int port = newNode.getPort();

        DatagramPacket searchPacket = new DatagramPacket(searchMsg.getBytes(), searchMsg.length(), ip, port);
        try {
            socket.send(searchPacket);
        } catch (IOException io) {
            io.printStackTrace();
        }
        String dataSent = new String(searchPacket.getData());
        logger.info(dataSent + " search2 msg flooded in DS at " + port);
    }
}