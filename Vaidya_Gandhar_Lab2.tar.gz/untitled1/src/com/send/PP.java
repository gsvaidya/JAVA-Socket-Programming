package com.send;

import com.ReceiveModule.Rb;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

/**
 * Created by gandhar on 2/22/16.
 */
public class PP implements Runnable {
    Rb tb;
    PacketBuffer pbuff;
    long Rp;
    double packetSize;
    int numberOfFrames;
    double waitedInPP;
    double pp;
    Logger slogger = Logger.getLogger("Send-log");

    public double getWaitedInPP() {
        return waitedInPP;
    }

    public PP(Rb tb, PacketBuffer pbuff,double pp,FileHandler s) throws IOException {
        this.tb = tb;
        this.pbuff = pbuff;
        this.pp = pp;



    }

    @Override
    public void run() {
        while (true) {
            /*System.out.println(pbuff.getPacketQueue().isEmpty());*/
            if ((packetSize = pbuff.removefromQueue()) != 0)
            {
//                System.out.println(packetSize/1526);

                numberOfFrames= (int) Math.ceil(packetSize / 1526);

                slogger.info("sent"+numberOfFrames+"frames to Transmit Buffer");
                /*System.out.println(numberOfFrames);*/
                for (int i = 0; i < numberOfFrames; i++) {

                    while (true) {
                        if (tb.addToRb()) {
                            //Thread.sleep
                            break;
                        }
                    }
                }
                try {
                    double delay = (numberOfFrames*2*1526*8)/1000;
                    Thread.sleep((long) delay);
                    waitedInPP += delay;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        }
    }
}