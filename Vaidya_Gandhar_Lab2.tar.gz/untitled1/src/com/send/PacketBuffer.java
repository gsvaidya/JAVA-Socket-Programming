package com.send;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Logger;

/**
 * Created by gandhar on 2/22/16.
 */
public class PacketBuffer {
private Queue<Long> packetQueue; //messages
    long queueMaxSize;
    long currentSize;
    Logger slogger = Logger.getLogger("Send-log");

    public long getQueueMaxSize() {
        return queueMaxSize;
    }

    public PacketBuffer(long queueMaxSize) {
        this.queueMaxSize = queueMaxSize;
        this.packetQueue = new ConcurrentLinkedQueue<Long>();

    }

    public long getCurrentSize() {
        return currentSize;
    }

    public Queue<Long> getPacketQueue() {
        return packetQueue;
    }

    public boolean addToQueue(long size){
        if(currentSize+size<queueMaxSize) {
            packetQueue.add(size);
            currentSize += size;
            return true;
        }
        return false;
    }
    public long removefromQueue(){
        if(!packetQueue.isEmpty()){
            Long remove = packetQueue.poll();
            currentSize -= remove;
            return remove;
        }return 0;
    }

}
