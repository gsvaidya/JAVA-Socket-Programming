package com.send;

import org.apache.commons.math3.distribution.ExponentialDistribution;
import org.apache.commons.math3.distribution.PoissonDistribution;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

/**
 * Created by gandhar on 2/22/16.
 */
public class genmsg implements Runnable {
    int lambdaU;
    int lambdaL;
    PacketBuffer pbuff;
    int meanL;
    Logger slogger = Logger.getLogger("Send-log");
    //public FileHandler s;

    public genmsg(int lambdaU, int lambdaL, PacketBuffer pbuff,int meanL,FileHandler s) throws IOException {

        this.lambdaU = lambdaU;
        this.lambdaL = lambdaL;
        this.pbuff = pbuff;
        this.meanL = meanL;


        slogger.addHandler(s);
    }


    @Override
    public void run() {
        PoissonDistribution num = new PoissonDistribution(lambdaL + lambdaU / 2);
        ExponentialDistribution size = new ExponentialDistribution(meanL);//main.ls);
        while (true) {
            long[] sizes = new long[num.sample()];
            slogger.info("generated"+sizes.length + "Messages");
            for (int i = 0; i < sizes.length; i++) {
                sizes[i] = (int) size.sample();
                if (sizes[i] > 64000) {
                    sizes[i] = 64000;
                }
                if (sizes[i] > 0) {
                    while (true) {
                        //System.out.println(pbuff.getQueueMaxSize());
                        if (pbuff.addToQueue(sizes[i]))
                            break;
                    }
                }

            }

        }


    }


}

