package com.ReceiveModule;

import com.MAC.MAC;

import java.io.IOException;
import java.util.Random;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

/**
 * Created by gandhar on 2/22/16.
 */
public class Rx implements Runnable {
    double Ps;
    MAC mc;
    Rb rb;
    Random rand = new Random();
    double var;
    int count;
    double waitedInRx;
    Logger logger = Logger.getLogger("Controller-log");


    public double getWaitedInRx() {
        return waitedInRx;
    }

    public int getCount() {
        return count;
    }

    public Rx(double ps, MAC mc, Rb rb,FileHandler mm) throws IOException {
        Ps = ps;
        this.mc = mc;
        this.rb = rb;

        logger.addHandler(mm);
    }

    @Override
    public void run() {
        count = 0;
        while (true) {

            if (!mc.getMode()) {
                var = rand.nextDouble();
                if (Ps > var) {
                    if (rb.addToRb()) {
                        rb.getReceiveQueue().add(1L);
                        logger.info("pulled" + rb.getReceiveQueue().size() + "packets from MM");
                        try {
                            double delay = (1526 * 8 * 0.3);
                            Thread.sleep((long) (delay));
                            waitedInRx+=delay;
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }count++;
                }
            }

        }
    }
