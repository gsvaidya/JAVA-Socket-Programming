package com.ReceiveModule;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

/**
 * Created by gandhar on 2/22/16.
 */
public class Rb {

    private Queue<Long> ReceiveQueue; //frames
    long ReceiveQueueMaxSize;
    Logger rlogger = Logger.getLogger("Receive-log");


    public Queue<Long> getReceiveQueue() {
        return ReceiveQueue;
    }



    public Rb(long receiveQueueMaxSize,FileHandler r) throws IOException {
        ReceiveQueueMaxSize = receiveQueueMaxSize;
        this.ReceiveQueue = new  ConcurrentLinkedQueue<>();

        rlogger.addHandler(r);
    }
    public boolean addToRb(){
        if(ReceiveQueue.size()+1<=ReceiveQueueMaxSize){
            ReceiveQueue.add(1L);
            return true;
        }return false;

    }
    public boolean popFromRb(){
        if(!ReceiveQueue.isEmpty()){
            ReceiveQueue.poll();
            return true;
        }return false;
    }

}
