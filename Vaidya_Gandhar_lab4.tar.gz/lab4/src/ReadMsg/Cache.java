package ReadMsg;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;

/**
 * Created by gandhar on 4/2/16.
 */
public class Cache {


    public static void sendCache(String part, ArrayList<cInfo> cList, DatagramSocket s, routingTable rout, ArrayList<Node> hostNode) {
        //get Ip and fname from cList and then send it to the routing table of the host node
        //hostnode , hostnode routing table.
        for (int k = 0; k < rout.size(); k++) {
            String ip = hostNode.get(k).getIp();
            int port =  hostNode.get(k).getPort();

            InetAddress iP = null;
            String ip2 = editAddr.edit(ip);

            try {
                iP = InetAddress.getByName(ip2);
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }
            String messAge = "cache "+part;
            byte[] sendCache = messAge.getBytes();

            DatagramPacket cachePacket = new DatagramPacket(sendCache,sendCache.length,iP,port);
            try {
                s.send(cachePacket);
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
    }
}