package ReadMsg;

import java.util.ArrayList;

/**
 * Created by gandhar on 4/2/16.
 */
public class cacheList {
    public ArrayList<cInfo> cacheList;

    public cacheList(ArrayList<cInfo> cacheList) {
        this.cacheList = cacheList;
    }

    public void add(cInfo e){
        cacheList.add(e);
    }

    public void remove(){
        cacheList.remove(1);
    }
}
