package ReadMsg;

import java.util.ArrayList;

/**
 * Created by gandhar on 3/10/16.
 */
public class regResponse {

    public static ArrayList<Node> getReg(String msg) {

        String[] s = msg.split(" ");
        int numberOfNodes = Integer.valueOf(s[3]);
        ArrayList<Node> ipPort = new ArrayList<Node>();

        if (numberOfNodes == 1 || numberOfNodes == 2 || numberOfNodes == 3) {
            for (int i = 0; i < numberOfNodes; i++) {
                ipPort.add(new Node(s[(2 * i) + 4], Integer.parseInt(s[(2 * i) + 5])));
            }
        }
        return ipPort;
    }
}
    /*{
        switch (numberOfNodes) {
            case 1:
                try {
                    InetAddress ip = InetAddress.getByName(s[3]);
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }
                Integer port = Integer.valueOf(s[4]);
                b = true;
                break;

            case 2:
                try {
                    InetAddress ip1 = InetAddress.getByName(s[3]);
                    InetAddress ip2 = InetAddress.getByName(s[5]);
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }
                Integer port1 = Integer.valueOf(s[4]);
                Integer port2 = Integer.valueOf(s[6]);
                b = true;
                break;

            case 3:
                try {
                    InetAddress ip1 = InetAddress.getByName(s[3]);
                    InetAddress ip2 = InetAddress.getByName(s[5]);
                    InetAddress ip3 = InetAddress.getByName(s[7]);
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }
                port1 = Integer.valueOf(s[4]);
                port2 = Integer.valueOf(s[6]);
                Integer port3 = Integer.valueOf(s[8]);
                b = true;
                break;

            case 0:
                System.out.println("no nodes in the system");
                b = false;
                break;
            case 9999:
                System.out.println("eEror in registering");
                b = false;
                break;
            case 9998:
                System.out.println("already registered, please unregister first");
                b = false;
                break;
            default:
                System.out.println("Unkown REG command");
                b = false;

        }*/

