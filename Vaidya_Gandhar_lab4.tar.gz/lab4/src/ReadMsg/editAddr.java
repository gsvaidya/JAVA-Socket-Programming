package ReadMsg;

/**
 * Created by gandhar on 3/18/16.
 */
public class editAddr {

    public static String edit(String cAddr) {
        String result = cAddr.replace("/", "");

        return result;
    }
}
