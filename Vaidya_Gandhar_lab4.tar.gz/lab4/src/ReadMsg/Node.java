package ReadMsg;

/**
 * Created by gandhar on 3/10/16.
 */
public class Node {
    String Ip;
    int port;


    public Node(String ip, int port) {
        this.Ip = ip;
        this.port = port;
    }

    public String getIp() {
        return Ip;
    }

    public int getPort() {
        return port;
    }

}