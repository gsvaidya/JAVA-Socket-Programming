package ReadMsg;

/**
 * Created by gandhar on 4/2/16.
 */
public class cInfo {

    String iP;
    String keyword;

    public cInfo(String iP, String keyword) {
        this.iP = iP;
        this.keyword = keyword;
    }

    public String getiP() {
        return iP;
    }

    public String getKeyword() {
        return keyword;
    }
}
