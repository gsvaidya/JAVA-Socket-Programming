package ReadMsg;

import java.util.ArrayList;

/**
 * Created by gandhar on 3/10/16.
 */
public class routingTable {
    public ArrayList<Node> Table;

    public routingTable(ArrayList<Node> table) {
        Table = table;
    }

    public int size() {
        return Table.size();
    }

    public void join(Node n) {
        Table.add(n);
    }

    public ArrayList<Node> getTable() {
        return Table;
    }

    public void delete(Node n) {
        Table.remove(n);
    }

}

