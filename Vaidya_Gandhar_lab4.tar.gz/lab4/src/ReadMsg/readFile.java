package ReadMsg;

import org.apache.commons.math3.distribution.ZipfDistribution;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by gandhar on 3/19/16.
 */
public class readFile {

    String fileName;

    public readFile(String fileName) {
        this.fileName = fileName;
    }


    public String[] readFile() throws IOException {
        BufferedReader in = new BufferedReader(new FileReader("/home/gandhar/ece658/lab4/src/resources.txt"));
        String str;

        List<String> list = new ArrayList<String>();
        while ((str = in.readLine()) != null) {
            list.add(str);
        }

        String[] stringArr = list.toArray(new String[0]);
        /*Scanner scan = new Scanner(System.in);
        System.out.println("enter number of resources");*/
        int noOfQueries = 8; //scan.nextInt();
        String s[] = new String[noOfQueries];
        for (int i = 0; i < noOfQueries; i++) {
            ZipfDistribution zipfDistribution = new ZipfDistribution(list.size(), 0.2);
            int num = zipfDistribution.sample();
            s[i] = stringArr[num];
        }
            /*Random rand = new Random();
            int num = rand.nextInt(161);
            s[i] = stringArr[num];*/
        for (int i = 0; i < noOfQueries; i++) {
            System.out.println(s[i]);
        }
        return s;
    }
}






