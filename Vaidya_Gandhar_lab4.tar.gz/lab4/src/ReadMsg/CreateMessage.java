package ReadMsg;

import java.net.InetAddress;
import java.text.DecimalFormat;

/**
 * Created by gandhar on 3/2/16.
 */
public class CreateMessage {


    public static String regMsg(String ip, Integer portNumber, String uName) {
        String str;
        str = ip + " " + portNumber.toString() + " " + uName;
        Integer len = str.length() + 9;
        String var4 = "0000" + len.toString();
        String var5 = var4.substring(var4.length() - 4, var4.length());
        String msg = var5 + " " + "REG" + " " + str;
        return msg;
    }

    public static String unregMsg(String ipAddr, Integer portNumber, String uName) {
        String var3 = " DEL IPADDRESS " + ipAddr + " " + portNumber + " " + uName;
        Integer len = var3.length() + 4;
        DecimalFormat nf4 = new DecimalFormat("#0000");
        String length = nf4.format(len);
        return length + var3;
    }

    public static String unregisteruser(String uName) {
        String var1 = " DEL UNAME " + uName;
        DecimalFormat nf4 = new DecimalFormat("#0000");
        Integer len = var1.length() + 4;
        String length = nf4.format(len);
        return length + var1;
    }

    public static String join(boolean b, String ipAddr, Integer portNum) {
        String var2;
        if (b) {
            var2 = " JOIN " + ipAddr + " " + portNum;
        } else {
            var2 = " LEAVE " + ipAddr + " " + portNum;
        }
        DecimalFormat nf4 = new DecimalFormat("#0000");
        Integer len = var2.length() + 4;
        String length = nf4.format(len);
        return length + var2;
    }

    public static String joinOk() {
        return "0013 JOINOK 0";

    }

    public static String leaveOk() {
        return "0013 LEAVEOK 0";
    }

    public static String search(String nodeIp, Integer nodePort, String fileName, Integer hops)
    {
        String var4 = " SER " + nodeIp + " " + nodePort.toString() + " " + fileName +" "+ hops.toString();
        DecimalFormat nf4 = new DecimalFormat("#0000");
        Integer len = var4.length() + 4;
        String length = nf4.format(len);
        return length + var4;


    }


    public static String SearchResponse(InetAddress hostIp, int hostPort, int hops, int i, String part) {
        String fname = null;
        StringBuilder sb = new StringBuilder();

        String ip = hostIp.toString();
        String hIp = editAddr.edit(ip);
        String s = " SEROK " + hIp + " " + String.valueOf(hostPort) + " " + String.valueOf(hops) + " " + part;
        DecimalFormat nf4 = new DecimalFormat("#0000");
        Integer len = s.length() + 4;
        String length = nf4.format(len);
        return length + " " + i + s;
    }
}

