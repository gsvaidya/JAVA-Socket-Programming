package ReadMsg;

import BootStrap.addNodes;
import BootStrap.removeNodes;
import BootStrap.searchDs;
import org.apache.commons.math3.distribution.ZipfDistribution;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

/**
 * Created by gandhar on 3/18/16.
 */
public class processReq implements Runnable {
    public DatagramSocket socket;
    public InetAddress hostIp;
    public int hostPort;
    public String name;
    public InetAddress bootIp;
    public int bPort;
    public String[] resources;
    public routingTable rout;
    public ArrayList<Node> hostNode;
    public ArrayList<String> fileList;
    public int ns;
    public int str;
    public int count;
    FileHandler hostlog;
    Logger logger = Logger.getLogger("Hostname Log");
    private String check;
    ArrayList<cInfo> cList;

    public processReq(ArrayList<cInfo> cList, int ns, DatagramSocket socket, InetAddress hostIp, int hostPort, String name, InetAddress bootIp, int bPort, String[] resources, routingTable rout, ArrayList<Node> hostNode, FileHandler hostLog) {
        this.cList = cList;
        this.ns = ns;
        this.socket = socket;
        this.hostIp = hostIp;
        this.hostPort = hostPort;
        this.name = name;
        this.bootIp = bootIp;
        this.bPort = bPort;
        this.resources = resources;
        this.rout = rout;
        this.hostNode = hostNode;
        this.hostlog = hostLog;
        logger.addHandler(hostLog);

    }

    public void run() {
        ArrayList<Node> table = rout.getTable();
        getResources files2 = new getResources();
        try {
            fileList = files2.getResources();
        } catch (IOException e) {
            e.printStackTrace();
        }
        getNodes nodeNum = new getNodes();
        logger.info("Waiting...");
        while (true) {
            byte[] joinReceiveDataFromBs = new byte[1024];
            DatagramPacket packetFromBs = new DatagramPacket(joinReceiveDataFromBs, joinReceiveDataFromBs.length);

            try {
                socket.receive(packetFromBs);
            } catch (IOException e) {
                e.printStackTrace();
            }
            int receivingPort = packetFromBs.getPort();
            String msg = new String(packetFromBs.getData());
            String message = msg.trim();



            if(message.contains("cache")){
                //store filename and ip in a list called entry
                //check if the list is full; if full replace the last entry with the new entry;else just add the new entry

                System.out.println("Storing cache");
                String[] cMsg = message.split(" ");
                String content = cMsg[1];
                System.out.println(content+" content");
                String cacheIp = packetFromBs.getAddress().toString();

                if(cList.size()==2)
                {
                cList.remove(1);
                cList.add(new cInfo(cacheIp,content));
                }
                else
                cList.add(new cInfo(cacheIp,content));
                for(int j=0;j<cList.size();j++){
                    System.out.println(cList.get(j).getKeyword()+" cache ");
                }

                continue;

            }

            if (message.contains("GET IPLIST OK")) {
                System.out.println(message);
                String[] iplist = message.split(" ");
                int noOfIps = Integer.parseInt(iplist[5]);
                ArrayList<Node> ips = new ArrayList<Node>();
                for (int i = 0; i < noOfIps - 1; i++) {
                    String queryIp = iplist[(2 * i) + 8];
                    String queryPort = iplist[(2 * i) + 9];
                    Node n = new Node(queryIp, Integer.parseInt(queryPort));
                    ips.add(i, n);
                }

                for (int k = 0; k < 160; k++) {
                    ZipfDistribution zipfDistribution = new ZipfDistribution(fileList.size(), 0.2);
                    int num = zipfDistribution.sample();
                    String fname = fileList.get(num);
                    Collections.shuffle(ips);
                    for (int i = 0; i < ns; i++) {
                        //Random rand = new Random();
                        //int r = rand.nextInt(ns);
                        Node n2 = ips.get(i);
                        searchDs makeQuery = new searchDs(ns, socket, table, hostIp, hostPort, fname, n2, hostlog);
                        makeQuery.search2();
                    }
                }
                continue;
            }

            if (message.contains("REGOK")) {
                if ((nodeNum.getNodes(message) == 9999)) {
                    System.out.println("failed-there is error in registering");
                } else if (nodeNum.getNodes(message) == 9998) {
                    System.out.println("already registered with bootstrap");
                    System.exit(0);
                } else if (nodeNum.getNodes(message) == 0) {
                    System.out.println("no nodes in the system");
                } else {
                    ArrayList<Node> response = regResponse.getReg(message);

                    for (int j = 0; j < response.size(); j++) {
                        String joinIp = hostIp.toString();

                        String joinMsg = CreateMessage.join(true, joinIp, socket.getLocalPort());
                        String Ip = response.get(j).getIp();
                        String newIp = editAddr.edit(Ip);

                        InetAddress ip = null;
                        try {
                            ip = InetAddress.getByName(newIp);
                        } catch (UnknownHostException un) {
                            un.printStackTrace();
                        }
                        int port = response.get(j).getPort();

                        DatagramPacket joinPacket = new DatagramPacket(joinMsg.getBytes(), joinMsg.length(), ip, port);
                        try {
                            socket.send(joinPacket);
                        } catch (IOException io) {
                            io.printStackTrace();
                        }
                        String dataSent = new String(joinPacket.getData());
                        logger.info(dataSent + " sent to ip" + ip + " on " + port);

                    }

                    /*try {
                        currentPort = req.JoinReq(socket,response);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }*/


                }
                continue;
            }

            if (message.contains("JOINOK")) {

                String ip = packetFromBs.getAddress().toString();
                int port = packetFromBs.getPort();
                addNodes.add(rout, message, ip, port);

                continue;
            }


            if (message.contains("LEAVEOK")) {
                /*String[] l = message.split(" ");
                int length = Integer.parseInt(l[0]);
                message = message.substring(0, length + 5);*/

                String ip = packetFromBs.getAddress().toString();
                int port = packetFromBs.getPort();
                removeNodes.remove(rout, message, ip, port);

                String delMsg = CreateMessage.unregMsg(hostIp.toString(), hostPort, name);
                InetAddress bsIP = bootIp; //use extract message class
                byte[] sendData = delMsg.getBytes();//
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, bsIP, bPort);
                try {
                    socket.send(sendPacket);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                continue;
            }


            if (message.contains("LEAVE")) {
                try {

                    String leave = editAddr.edit(message);

                    String[] msg2 = leave.split(" ");
                    Node node = new Node(msg2[2], Integer.parseInt(msg2[3]));
                    InetAddress ip = InetAddress.getByName(msg2[2]);
                    int port = Integer.parseInt(msg2[3]);
                    logger.info(message + " received from " + ip.toString() + " " + port);
                    rout.delete(node);
                    String full = CreateMessage.leaveOk();

                    byte[] sendData = full.getBytes();//
                    DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, ip, port);
                    socket.send(sendPacket);
                    logger.info(full + " sent to " + port);

                } catch (IOException iox) {
                    iox.printStackTrace();
                }
                continue;
            }


            if (message.contains("JOIN")) {

                logger.info(message + " received");
                String[] msg2 = message.split(" ");
                Node node = new Node(msg2[2], Integer.parseInt(msg2[3]));
                rout.join(node);
                logger.info("added " + msg2[3] + " to the routing table ");
                String full = CreateMessage.joinOk();
                InetAddress ip = null;
                String jIp = editAddr.edit(msg2[2]);
                try {
                    ip = InetAddress.getByName(jIp);
                } catch (UnknownHostException u) {
                    u.printStackTrace();
                }
                int port = Integer.parseInt(msg2[3]);

                byte[] sendData = full.getBytes();//
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, ip, port);

                try {
                    socket.send(sendPacket);
                    String packet = new String(sendPacket.getData());
                    logger.info(packet + " sent to" + ip + " " + port);
                } catch (IOException x) {
                    x.printStackTrace();
                }
                continue;
            }
            if (message.contains("DEL IPADDRESS OK")) {
                String[] l = message.split(" ");
                logger.info(message);

                if (Integer.parseInt(l[7]) == 1) {
                    System.exit(0);
                } else
                    System.out.println("error unregistering");
                continue;
            }
            if (message.contains("DEL UNAME OK")) {
                String[] l = message.split(" ");
                if (Integer.parseInt(l[4]) == 0)
                    System.exit(0);
                else System.out.println("error unregistering");
                continue;
            }


            if (message.contains("SEROK")) {
                String[] l = message.split(" ");
                String ip = l[3];
                logger.info(message + "received");
                int port = Integer.parseInt(l[4]);
                int value = Integer.parseInt(l[1]);
                StringBuilder bs = new StringBuilder();
                String part2 = null;
                for (int t = 4; t < (l.length); t++) {

                    bs.append(l[t]);
                    bs.append(" ");
                    part2 = bs.toString();
                }
                part2.trim();
                if (value == 0) {
                    System.out.println("no matching results");
                } else if (value == 9999) {
                    System.out.println("node unreachable");
                } else if (value == 9998) {
                    System.out.println("other error");
                } else {
                    System.out.println(part2 + " found at node with " + ip + " at " + port + "with " + l[5] + "hops");

                }
                continue;
            }

            if (message.contains("SER")) {
                int hops;
                str = str + 1;
                String reqInitatedat = packetFromBs.getAddress().toString();
                String requestSource = editAddr.edit(reqInitatedat);
                //whenever you get a request matching that fname , send it to the concerned node with the ip from content and decrement hop count.
                String[] search = message.split(" ");
                logger.info(message + " msg received from" + packetFromBs.getPort());
                InetAddress searchIp = null;
                String sIp = editAddr.edit(search[2]);
                try {
                    searchIp = InetAddress.getByName(sIp);
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }

                int searchPort = Integer.parseInt(search[3]);


                String part = null;
                StringBuilder sb = new StringBuilder();

                for (int i = 4; i < (search.length) - 1; i++) {

                    sb.append(search[i]);
                    sb.append(" ");
                    part = sb.toString();
                }
                part = part.trim();
                hops = Integer.parseInt(search[search.length - 1]);

                if(cList.size()!=0){
                    for(int j=0;j<cList.size();j++){
                        String cIp = cList.get(j).getiP();
                        String content = cList.get(j).getKeyword();


                        if(part.contains(content))
                        {
                            System.out.println("using cached information");
                            hops -=1;
                            String ip2 = editAddr.edit(cIp);
                            InetAddress ip = null;
                            try {
                                ip = InetAddress.getByName(ip2);
                            } catch (UnknownHostException e) {
                                e.printStackTrace();
                            }
                            String serOk = CreateMessage.SearchResponse(ip, hostPort, hops, 1, part);
                            byte[] send = serOk.getBytes();
                            if(searchIp!=hostIp){
                                DatagramPacket sPacket = new DatagramPacket(send,send.length,searchIp,searchPort);
                                try {
                                    socket.send(sPacket);
                                } catch (IOException e) {

                                }
                                System.out.println("cache information sent to "+searchIp);
                            }

                        }
                    }
                }

                ArrayList<String> hit = new ArrayList<String>();

                for (int i = 0; i < resources.length; i++) {
                    int j = 0;
                    if (resources[i].contains(part))//filefound)
                    {
                        hit.add(j, resources[i]);
                        j++;
                    }
                }

                if (hit.size() != 0) {
                    if (count == 0) {
                        //System.out.println("hitsize not" + hit.size());
                        hops = hops + 1;
                        count++;
                        String serOkMessage = CreateMessage.SearchResponse(hostIp, hostPort, hops, 1, part);
                        byte[] sendData = serOkMessage.getBytes();//

                        if (searchIp != hostIp || searchPort != hostPort) {
                            //send part and hostIp to its routing table for caching that info at those nodes

                            Cache.sendCache(part,cList,socket,rout,hostNode);

                            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, searchIp, searchPort);
                            try {
                                socket.send(sendPacket);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            logger.info(serOkMessage + " sent to " + searchIp + " at " + searchPort + "from" + hostIp + " " + hostPort);

                        }
                    }
                } else {
                    hops = hops + 1;

                    System.out.println("file not found at this node" + hostIp);
                    logger.info(part + " saw " + str + "nodes");
                    int files = hit.size();
                    if (searchIp != hostIp || searchPort != hostPort) {
                        String serOkMessage = CreateMessage.SearchResponse(hostIp, hostPort, hops, 0, part);

                        byte[] sendData = serOkMessage.getBytes();//
                        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, searchIp, searchPort);
                        logger.info(new String(sendPacket.getData()) + " sending packet");
                        try {

                            socket.send(sendPacket);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    if (hops < 5) {

                        for (int k = 0; k < rout.size(); k++) {

                            String ip = hostNode.get(k).getIp();
                            int port = hostNode.get(k).getPort();


                            InetAddress iP = null;
                            String ip2 = editAddr.edit(ip);
                            try {
                                iP = InetAddress.getByName(ip2);
                            } catch (UnknownHostException e) {
                                e.printStackTrace();
                            }

                            if (iP != searchIp || searchPort != port) {
                                try {
                                    if (iP != (InetAddress.getByName(requestSource)) || port != packetFromBs.getPort()) {
                                        String forwardMsg = CreateMessage.search(searchIp.toString(), searchPort, part, hops);
                                        byte[] fileReqToRout = forwardMsg.getBytes();
                                        DatagramPacket fileReqPacket = new DatagramPacket(fileReqToRout, fileReqToRout.length, iP, port);
                                        try {
                                            socket.send(fileReqPacket);
                                            //logger.output
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                } catch (UnknownHostException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }
                }
                continue;
            }
        }
    }

}