package BootStrap;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

/**
 * Created by gandhar on 3/8/16.
 */
public class sendToBs {

    DatagramSocket socket;
    String msg;
    int bsPort;
    InetAddress bsAddr;
    int nPort;

    public sendToBs(DatagramSocket socket, String msg, int bsPort, InetAddress bsAddr, int nPort) {
        this.socket = socket;
        this.msg = msg;
        this.bsPort = bsPort;
        this.bsAddr = bsAddr;
        this.nPort = nPort;
    }

    public void sendToBootStrap() throws IOException {
        int bootPort = bsPort;
        int nodePort = nPort;


        try {
            /*port = nodeSocket.getLocalPort();*/
            InetAddress bsIP = bsAddr; //use extract message class
            byte[] sendData = msg.getBytes();//
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, bsIP, bootPort);
            socket.send(sendPacket);

        } catch (SocketException e) {
            e.printStackTrace();
        }
        //receive
    }
}