package BootStrap;

import ReadMsg.Node;
import ReadMsg.routingTable;

/**
 * Created by gandhar on 3/18/16.
 */
public class addNodes {


    public static boolean add(routingTable rout, String request, String ip, int port) {
        boolean b = false;

        //splitting join request to get ip and port no.
        String[] msg = request.split(" ");
        //using ip and port to add to routing table
        Node n = new Node(ip, port);
        if (Integer.parseInt(msg[2]) == 0) {
            rout.join(n);
            System.out.println(port + "added successfully");
            b = true;
        } else if (Integer.parseInt(msg[2]) == 9999) {
            System.out.println(ip + "could not be added to the routing table");
            b = false;
        }
        return b;
    }
}
