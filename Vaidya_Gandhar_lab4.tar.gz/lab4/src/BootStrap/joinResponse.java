package BootStrap;

import java.io.IOException;
import java.net.DatagramSocket;

/**
 * Created by gandhar on 3/9/16.
 */
public class joinResponse {

    static int port;

    public static void processJoin(DatagramSocket socket, String request) throws IOException {

    }
}