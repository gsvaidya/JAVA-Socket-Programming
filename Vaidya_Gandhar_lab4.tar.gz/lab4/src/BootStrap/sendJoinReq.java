package BootStrap;

import ReadMsg.Node;
import ReadMsg.routingTable;

import java.io.IOException;
import java.net.DatagramSocket;
import java.util.ArrayList;

/**
 * Created by gandhar on 3/16/16.
 */


public class sendJoinReq {

    public int port;
    routingTable rout;
    private ArrayList<Node> response;

    /*public sendJoinReq(ArrayList<Node> response) {
        this.response = response;
    }*/
    //take the message from bootstrap and send join requests to the ip
    public int JoinReq(DatagramSocket socket, ArrayList<Node> list) throws IOException {

        return port;
    }
}