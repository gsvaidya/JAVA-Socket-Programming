package BootStrap;

import ReadMsg.Node;
import ReadMsg.routingTable;

/**
 * Created by gandhar on 3/18/16.
 */
public class removeNodes {

    routingTable rout;

    public removeNodes(routingTable rout) {
        this.rout = rout;
    }

    public static boolean remove(routingTable rout, String request, String ip, int port) {
        boolean b = false;
        //splitting join request to get ip and port no.
        String[] msg = request.split(" ");
        //using ip and port to add to routing table
        Node n = new Node(ip, port);
        if (Integer.parseInt(msg[2]) == 0) {
            rout.delete(n);
            System.out.println(ip + "left the system");
            b = true;
        } else if (Integer.parseInt(msg[2]) == 9999) {
            System.out.println(ip + "failed to leave");
            b = false;
        }
        return b;
    }
}
