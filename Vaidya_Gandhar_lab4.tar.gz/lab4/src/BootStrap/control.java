package BootStrap;

import ReadMsg.Node;
import ReadMsg.routingTable;
import com.sun.corba.se.spi.orbutil.fsm.FSM;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

/**
 * Created by gandhar on 3/19/16.
 */
public class control implements Runnable {
    routingTable rout;
    DatagramSocket socket;
    InetAddress ip;
    int portNum;
    InetAddress bsAddr;
    String uname;
    Logger logger = Logger.getLogger(" ");
    private FileHandler Fs;

    public control(DatagramSocket socket, InetAddress ip, int portNum, routingTable rout, InetAddress bsAddr, String uname,FileHandler Fs) {
        this.socket = socket;
        this.ip = ip;
        this.portNum = portNum;
        this.rout = rout;
        this.bsAddr = bsAddr;
        this.uname = uname;
        logger.addHandler(Fs);
        this.Fs = Fs;
    }


    @Override
    public void run() {
        while (true) {
            Node k = new Node("abcd",123);
            ArrayList<Node> table = rout.getTable();
            Scanner scan = new Scanner(System.in);
            String msg = scan.nextLine();
            if (msg.contains("quit")) {
                leaveDistributedSystem leaving = new leaveDistributedSystem(socket, table, ip, portNum);
                try {
                    leaving.leave();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                continue;
            }

            BufferedReader in = null;
            try {
                in = new BufferedReader(new FileReader("/home/gandhar/ece658/lab4/src/resources.txt"));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            String str;

            List<String> list = new ArrayList<String>();
            try {
                while ((str = in.readLine()) != null) {
                    list.add(str);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            if (msg.contains("query")) {
                System.out.println("Enter keyword for filename");
                Scanner scan2 = new Scanner(System.in);
                String fname = scan2.nextLine();
                searchDs makeQuery = new searchDs(0, socket, table, ip, portNum, fname, k,Fs);
                makeQuery.search();
                continue;
            }

            if (msg.contains("search")) {

                InetAddress bsIP = bsAddr; //use extract message class
                String ipList = " GET IPLIST " + uname;
                int len = ipList.length() + 5;
                DecimalFormat nf4 = new DecimalFormat("#0000");
                String length = nf4.format(len);
                String getIpList = length + ipList;
                System.out.println(getIpList);

                byte[] sendData = getIpList.getBytes();//
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, bsIP, 10000);
                try {
                    socket.send(sendPacket);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
    }
}
