import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

public class rscmnd
{
    public static void main(String[] args) throws IOException, InterruptedException {
        for(int a=0;a<args.length;a++){

            if (args[a].equals("help"))
            {
                System.out.println("The order of arguments for TCP programs is\n"+
                        "servername,serverport,execution count,time delay in milliseconds,command");
                System.exit(0);
            }
        }

        int clientport = Integer.parseInt(args[0]);
        DatagramSocket serversocket = new DatagramSocket(clientport);
        InetAddress add = InetAddress.getLocalHost();
        System.out.println("server is on with IP address:" + add.getHostAddress());
        byte[] receiveData = new byte[1024];
        String send = "";

        SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
        String s = "";

while(true) { //data reception
    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
    serversocket.receive(receivePacket);
    String datareceived = new String(receivePacket.getData());
    //System.out.println(datareceived);
    System.out.println("message received from Client");
    String[] parts = datareceived.split(",");

    //System.out.println(parts[0]);

    int executioncount = Integer.parseInt(parts[0]);
    int delaytime = Integer.parseInt(parts[1]);


    //System.out.println("delay time is " +delaytime);
    InetAddress clientaddress = receivePacket.getAddress();
    System.out.println("Client address is: " + clientaddress);


    System.out.println("executing and sending to client");

    //System.out.println(executioncount);
    for (int j = 0; j < executioncount; j++) {
        Date timestamp = new Date();
        Process p = Runtime.getRuntime().exec(parts[2]);
        BufferedReader brInput = new BufferedReader
                (new InputStreamReader(p.getInputStream()));
        //s.concat("Execution number:" + (j + 1) + "\n");
        FileOutputStream file = new FileOutputStream("out.txt");
        while ((send = brInput.readLine()) != null) {

            //send = send.concat(send);
            //send = send.concat("\n");
            //file.write(s.getBytes());
            //send.concat(s);
            file.write(send.getBytes());
            file.write("\n".getBytes());

        }
        file.close();
        //add error

        //datasend = send.getBytes();


        Path path = Paths.get("", "out.txt");
        send = new String(Files.readAllBytes(path));

        send = send.concat("current time:" + df.format(timestamp));
        byte[] data = send.getBytes();
        DatagramPacket sendPacket = new DatagramPacket(data, data.length, clientaddress, receivePacket.getPort());
        serversocket.send(sendPacket);
        Thread.sleep(delaytime*1000);
        Files.delete(path);
    }





    System.out.println("status - closed");

}}}
/////////server