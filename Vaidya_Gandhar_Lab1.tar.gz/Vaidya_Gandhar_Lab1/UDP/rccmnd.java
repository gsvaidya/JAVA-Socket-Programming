/////client

import java.io.*;
import java.net.*;
import java.util.Date;

public class rccmnd
{
    public static void main(String[] args) throws IOException {
        for(int a=0;a<args.length;a++){

            if (args[a].equals("help"))
            {
                System.out.println("The order of arguments for TCP programs is\n"+
                        "servername,serverport,execution count,time delay in milliseconds,command");
                System.exit(0);
            }
        }

        DatagramSocket clientSocket = new DatagramSocket();
        InetAddress host = InetAddress.getByName(args[0]);
        int serverport = Integer.parseInt(args[1]);

        Date end = null;
        StringBuilder merge = new StringBuilder();
        for (int k=5; k<args.length; k++) {
            args[4]=args[4].concat(" "+args[k]);
        }

        for (int i = 2;i<5;i++)
        {
            merge.append(args[i]);
            merge.append(",");
        }
        //merge.append(host);
        //merge.append("-");
        //merge.append(serverport);

        //int executioncount = Integer.parseInt(args[2]);

        //sending Data

        byte[] sendData = merge.toString().getBytes();
        DatagramPacket sendPacket = new DatagramPacket(sendData,sendData.length, host, serverport);

        clientSocket.send(sendPacket);

        Date start = new Date();
        //receiving Data
        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData,receiveData.length);

        Integer execCount = Integer.parseInt(args[2]);
        for(int i=0; i<execCount; i++) {
            clientSocket.receive(receivePacket);

            if (i == 0) {
                end = new Date();
            }
            String fromserver = new String(receivePacket.getData());
            System.out.println("execution number" + (i + 1));
            System.out.println("From Server" + "\n" + fromserver);

        }
        long difference = end.getTime() - start.getTime();
        System.out.println("This whole process took:(RTT)"+difference+"ms");
        }}
