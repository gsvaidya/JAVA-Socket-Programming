import java.io.*;
import java.net.*;
import java.util.Date;

public class rccmnd {
	public static void main(String[] args) throws Exception {
		//args gives server name, server port, execution count, time delay and command

		//if (args.length != 5) //to check if correct number of arguments have been passed
		//throw new IllegalArgumentException("Illegal number of arguments");
		for(int a=0;a<args.length;a++){

			if (args[a].equals("help"))
			{
				System.out.println("The order of arguments for TCP programs is\n"+
						"servername,serverport,execution count,time delay in milliseconds,command");
				System.exit(0);
			}
		}
		InetAddress serveraddress = InetAddress.getByName(args[0]); //converting server name to IP address
		int serverport = Integer.parseInt(args[1]);
		Date end = null;
		String receiveddata = "";
		//Concatenating strings to send them as one string


		StringBuilder merge = new StringBuilder();

			for (int k = 5; k < args.length; k++) {
				args[4] = args[4].concat(" " + args[k]);
			}

			for (int i = 2; i < 5; i++) {
				merge.append(args[i]);
				merge.append(",");
			}

			System.out.println("creating client socket");
			int executioncount = Integer.parseInt(args[2]);
			//creating client socket

			Socket clientSocket = new Socket(serveraddress, serverport);
			PrintStream PS = new PrintStream(clientSocket.getOutputStream());

			System.out.println("writing");

			PS.println(merge.toString());
			Date start = new Date();
			System.out.println("written");


			//reading from server
			BufferedReader FromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			int count = 0;
			while ((receiveddata = FromServer.readLine()) != null) {
				if (count == 0) {
					end = new Date();
					count++;
				}
				System.out.println(receiveddata);
			}

			long difference = end.getTime() - start.getTime();
			System.out.println("This whole process took:" + difference + "ms");
		}
	}
