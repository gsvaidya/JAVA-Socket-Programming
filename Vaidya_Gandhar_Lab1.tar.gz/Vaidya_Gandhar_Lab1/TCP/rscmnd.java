import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
public class rscmnd {

    public static class MultiServer implements Runnable {
        Socket clientsocket;
        MultiServer(Socket clientsocket) {
            this.clientsocket = clientsocket;
        }


            public void run()
            {
                try {

                    SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
                    String s = "";
                    String reply = "";                                    //string that stores the output of the command
                    Process p;                                       //to execute the command in terminal



                    PrintStream pstream = new PrintStream(clientsocket.getOutputStream());

                    InputStreamReader ir = new InputStreamReader(clientsocket.getInputStream());
                    BufferedReader br2 = new BufferedReader(ir);

                    //receiving data from the server
                    String receiveddata = br2.readLine();

                    String send = "";
                    //extracting different information from the data received
                    String[] parts = receiveddata.split(",");

                    System.out.println("\nClient address:" + clientsocket.getRemoteSocketAddress() + "\ncommand:" + parts[2] + "\nstatus:connected\n\n");
                    Date timestamp;
                    int executioncount;
                    executioncount = Integer.parseInt(parts[0]);
                    int delaytime = Integer.parseInt(parts[1]);

                    PrintStream outToClient = new PrintStream(clientsocket.getOutputStream());

                    for (int j = 0; j < executioncount; j++) {


                        timestamp = new Date();      //to get the current time
                        //executing the command received from the client
                        p = Runtime.getRuntime().exec(parts[2]);
                        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));

                        FileOutputStream file = new FileOutputStream("out.txt");

                        while ((s = br.readLine()) != null) {

                            //file.write(send.getBytes());
                            file.write(s.getBytes());
                            file.write("\n".getBytes());

                        }

                        Path path = Paths.get("", "out.txt");

                        s = new String(Files.readAllBytes(path));
                        s = s.concat("executioncount: " + (j + 1) + "\n");


                        s = s.concat("current time:" + df.format(timestamp));
                        s = s.concat("\n");

                        outToClient.println(s);
                        try {
                            Thread.sleep(delaytime); // introducing delay between mutlitple executions
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                    }


                    System.out.println("status:closed");
                    reply = "";
                    pstream.close();
                    clientsocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
    }
    public static void main(String[] args) throws Exception {
        //args gives the port number.
        for(int a=0;a<args.length;a++){

            if (args[a].equals("help"))
            {
                System.out.println("The order of arguments for TCP programs is\n"+
                        "servername,serverport,execution count,time delay in milliseconds,command");
                System.exit(0);
            }
        }


            int clientport = Integer.parseInt(args[0]);

        //String receiveddata;

        //creating socket

        ServerSocket servsocket = new ServerSocket(clientport);
        InetAddress addr = InetAddress.getLocalHost();//receiving the IP address of the system

        //Inet6Address addr2 = Inet6Address.getLocalHost();


        System.out.println("Server is on with IP address: " + addr.getHostAddress());
        //System.out.println("Server is on with IPv6 address: " + addr2.getHostAddress());


        while (true) {

            Socket clientsocket = servsocket.accept();   //accepting connection from the client
            System.out.println("accepting");
            new Thread(new MultiServer(clientsocket)).start();

    }
    }


}